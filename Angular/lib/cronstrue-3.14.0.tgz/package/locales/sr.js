(function webpackUniversalModuleDefinition(root, factory) {
	if(typeof exports === 'object' && typeof module === 'object')
		module.exports = factory(require("cronstrue"));
	else if(typeof define === 'function' && define.amd)
		define("locales/sr", ["cronstrue"], factory);
	else if(typeof exports === 'object')
		exports["locales/sr"] = factory(require("cronstrue"));
	else
		root["locales/sr"] = factory(root["cronstrue"]);
})(globalThis, (__WEBPACK_EXTERNAL_MODULE__93__) => {
return /******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 93
(module) {

module.exports = __WEBPACK_EXTERNAL_MODULE__93__;

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var cronstrue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(93);
/* harmony import */ var cronstrue__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(cronstrue__WEBPACK_IMPORTED_MODULE_0__);
var sr_exports = __webpack_exports__;
"use strict";
Object.defineProperty(sr_exports, "__esModule", { value: true });
sr_exports.sr = void 0;
var sr = (function () {
    function sr() {
    }
    sr.prototype.use24HourTimeFormatByDefault = function () {
        return true;
    };
    sr.prototype.anErrorOccuredWhenGeneratingTheExpressionD = function () {
        return "Došlo je do greške pri generisanju izraza. Proverite sintaksu cron izraza.";
    };
    sr.prototype.at = function () {
        return "U";
    };
    sr.prototype.atSpace = function () {
        return "U ";
    };
    sr.prototype.atX0 = function () {
        return "u %s";
    };
    sr.prototype.atX0MinutesPastTheHour = function () {
        return "u %s minuta posle punog sata";
    };
    sr.prototype.atX0SecondsPastTheMinute = function () {
        return "u %s sekundi posle pune minute";
    };
    sr.prototype.betweenX0AndX1 = function () {
        return "između %s i %s";
    };
    sr.prototype.commaBetweenDayX0AndX1OfTheMonth = function () {
        return ", između %s. i %s. dana u mesecu";
    };
    sr.prototype.commaEveryDay = function () {
        return ", svaki dan";
    };
    sr.prototype.commaEveryX0Days = function () {
        return ", svakih %s dana";
    };
    sr.prototype.commaEveryX0DaysOfTheWeek = function () {
        return ", svakih %s dana u nedelji";
    };
    sr.prototype.commaEveryX0Months = function () {
        return ", svakih %s meseci";
    };
    sr.prototype.commaEveryX0Years = function () {
        return ", svakih %s godina";
    };
    sr.prototype.commaOnDayX0OfTheMonth = function () {
        return ", %s. dan u mesecu";
    };
    sr.prototype.commaOnlyInX0 = function () {
        return ", samo u %s";
    };
    sr.prototype.commaOnlyOnX0 = function () {
        return ", samo %s";
    };
    sr.prototype.commaAndOnX0 = function () {
        return ", i %s";
    };
    sr.prototype.commaOnThe = function () {
        return ", ";
    };
    sr.prototype.commaOnTheLastDayOfTheMonth = function () {
        return ", poslednjeg dana u mesecu";
    };
    sr.prototype.commaOnTheLastWeekdayOfTheMonth = function () {
        return ", poslednjeg radnog dana u mesecu";
    };
    sr.prototype.commaDaysBeforeTheLastDayOfTheMonth = function () {
        return ", %s dana pre kraja meseca";
    };
    sr.prototype.commaOnTheLastX0OfTheMonth = function () {
        return ", poslednji %s u mesecu";
    };
    sr.prototype.commaOnTheX0OfTheMonth = function () {
        return ", %s u mesecu";
    };
    sr.prototype.commaX0ThroughX1 = function () {
        return ", od %s do %s";
    };
    sr.prototype.commaAndX0ThroughX1 = function () {
        return ", i od %s do %s";
    };
    sr.prototype.everyHour = function () {
        return "svaki sat";
    };
    sr.prototype.everyMinute = function () {
        return "svakog minuta";
    };
    sr.prototype.everyMinuteBetweenX0AndX1 = function () {
        return "Svakog minuta između %s i %s";
    };
    sr.prototype.everySecond = function () {
        return "svake sekunde";
    };
    sr.prototype.everyX0Hours = function () {
        return "svakih %s sati";
    };
    sr.prototype.everyX0Minutes = function () {
        return "svakih %s minuta";
    };
    sr.prototype.everyX0Seconds = function () {
        return "svakih %s sekundi";
    };
    sr.prototype.fifth = function () {
        return "peti";
    };
    sr.prototype.first = function () {
        return "prvi";
    };
    sr.prototype.firstWeekday = function () {
        return "prvi radni dan";
    };
    sr.prototype.fourth = function () {
        return "četvrti";
    };
    sr.prototype.minutesX0ThroughX1PastTheHour = function () {
        return "minute od %s do %s posle punog sata";
    };
    sr.prototype.second = function () {
        return "drugi";
    };
    sr.prototype.secondsX0ThroughX1PastTheMinute = function () {
        return "sekunde od %s do %s posle pune minute";
    };
    sr.prototype.spaceAnd = function () {
        return " i";
    };
    sr.prototype.spaceX0OfTheMonth = function () {
        return " %s u mesecu";
    };
    sr.prototype.lastDay = function () {
        return "poslednji dan";
    };
    sr.prototype.third = function () {
        return "treći";
    };
    sr.prototype.weekdayNearestDayX0 = function () {
        return "radni dan najbliži %s. danu";
    };
    sr.prototype.commaMonthX0ThroughMonthX1 = function () {
        return null;
    };
    sr.prototype.commaYearX0ThroughYearX1 = function () {
        return null;
    };
    sr.prototype.atX0MinutesPastTheHourGt20 = function () {
        return null;
    };
    sr.prototype.atX0SecondsPastTheMinuteGt20 = function () {
        return null;
    };
    sr.prototype.commaStartingX0 = function () {
        return ", počevši od %s";
    };
    sr.prototype.daysOfTheWeek = function () {
        return [
            "Nedelja",
            "Ponedeljak",
            "Utorak",
            "Sreda",
            "Četvrtak",
            "Petak",
            "Subota",
        ];
    };
    sr.prototype.monthsOfTheYear = function () {
        return [
            "januar",
            "februar",
            "mart",
            "april",
            "maj",
            "jun",
            "jul",
            "avgust",
            "septembar",
            "oktobar",
            "novembar",
            "decembar",
        ];
    };
    sr.prototype.onTheHour = function () {
        return "u pun sat";
    };
    return sr;
}());
sr_exports.sr = sr;


(cronstrue__WEBPACK_IMPORTED_MODULE_0___default().locales)["sr"] = new sr();

/******/ 	return __webpack_exports__;
/******/ })()
;
});