(function webpackUniversalModuleDefinition(root, factory) {
	if(typeof exports === 'object' && typeof module === 'object')
		module.exports = factory(require("cronstrue"));
	else if(typeof define === 'function' && define.amd)
		define("locales/hr", ["cronstrue"], factory);
	else if(typeof exports === 'object')
		exports["locales/hr"] = factory(require("cronstrue"));
	else
		root["locales/hr"] = factory(root["cronstrue"]);
})(globalThis, (__WEBPACK_EXTERNAL_MODULE__93__) => {
return /******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 93
(module) {

module.exports = __WEBPACK_EXTERNAL_MODULE__93__;

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var cronstrue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(93);
/* harmony import */ var cronstrue__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(cronstrue__WEBPACK_IMPORTED_MODULE_0__);
var hr_exports = __webpack_exports__;
"use strict";
Object.defineProperty(hr_exports, "__esModule", { value: true });
hr_exports.hr = void 0;
var hr = (function () {
    function hr() {
    }
    hr.prototype.use24HourTimeFormatByDefault = function () {
        return true;
    };
    hr.prototype.anErrorOccuredWhenGeneratingTheExpressionD = function () {
        return "Došlo je do pogreške pri generiranju izraza. Provjerite sintaksu cron izraza.";
    };
    hr.prototype.at = function () {
        return "U";
    };
    hr.prototype.atSpace = function () {
        return "U ";
    };
    hr.prototype.atX0 = function () {
        return "u %s";
    };
    hr.prototype.atX0MinutesPastTheHour = function () {
        return "u %s minuta nakon punog sata";
    };
    hr.prototype.atX0SecondsPastTheMinute = function () {
        return "u %s sekundi nakon pune minute";
    };
    hr.prototype.betweenX0AndX1 = function () {
        return "između %s i %s";
    };
    hr.prototype.commaBetweenDayX0AndX1OfTheMonth = function () {
        return ", između %s. i %s. dana u mjesecu";
    };
    hr.prototype.commaEveryDay = function () {
        return ", svaki dan";
    };
    hr.prototype.commaEveryX0Days = function () {
        return ", svakih %s dana";
    };
    hr.prototype.commaEveryX0DaysOfTheWeek = function () {
        return ", svakih %s dana u tjednu";
    };
    hr.prototype.commaEveryX0Months = function () {
        return ", svakih %s mjeseci";
    };
    hr.prototype.commaEveryX0Years = function () {
        return ", svakih %s godina";
    };
    hr.prototype.commaOnDayX0OfTheMonth = function () {
        return ", %s. dan u mjesecu";
    };
    hr.prototype.commaOnlyInX0 = function () {
        return ", samo u %s";
    };
    hr.prototype.commaOnlyOnX0 = function () {
        return ", samo %s";
    };
    hr.prototype.commaAndOnX0 = function () {
        return ", i %s";
    };
    hr.prototype.commaOnThe = function () {
        return ", ";
    };
    hr.prototype.commaOnTheLastDayOfTheMonth = function () {
        return ", zadnji dan u mjesecu";
    };
    hr.prototype.commaOnTheLastWeekdayOfTheMonth = function () {
        return ", zadnji radni dan u mjesecu";
    };
    hr.prototype.commaDaysBeforeTheLastDayOfTheMonth = function () {
        return ", %s dana prije kraja mjeseca";
    };
    hr.prototype.commaOnTheLastX0OfTheMonth = function () {
        return ", zadnji %s u mjesecu";
    };
    hr.prototype.commaOnTheX0OfTheMonth = function () {
        return ", %s u mjesecu";
    };
    hr.prototype.commaX0ThroughX1 = function () {
        return ", od %s do %s";
    };
    hr.prototype.commaAndX0ThroughX1 = function () {
        return ", i od %s do %s";
    };
    hr.prototype.everyHour = function () {
        return "svaki sat";
    };
    hr.prototype.everyMinute = function () {
        return "svaku minutu";
    };
    hr.prototype.everyMinuteBetweenX0AndX1 = function () {
        return "Svaku minutu između %s i %s";
    };
    hr.prototype.everySecond = function () {
        return "svaku sekundu";
    };
    hr.prototype.everyX0Hours = function () {
        return "svakih %s sati";
    };
    hr.prototype.everyX0Minutes = function () {
        return "svakih %s minuta";
    };
    hr.prototype.everyX0Seconds = function () {
        return "svakih %s sekundi";
    };
    hr.prototype.fifth = function () {
        return "peti";
    };
    hr.prototype.first = function () {
        return "prvi";
    };
    hr.prototype.firstWeekday = function () {
        return "prvi radni dan";
    };
    hr.prototype.fourth = function () {
        return "četvrti";
    };
    hr.prototype.minutesX0ThroughX1PastTheHour = function () {
        return "minute od %s do %s nakon punog sata";
    };
    hr.prototype.second = function () {
        return "drugi";
    };
    hr.prototype.secondsX0ThroughX1PastTheMinute = function () {
        return "sekunde od %s do %s nakon pune minute";
    };
    hr.prototype.spaceAnd = function () {
        return " i";
    };
    hr.prototype.spaceX0OfTheMonth = function () {
        return " %s u mjesecu";
    };
    hr.prototype.lastDay = function () {
        return "zadnji dan";
    };
    hr.prototype.third = function () {
        return "treći";
    };
    hr.prototype.weekdayNearestDayX0 = function () {
        return "radni dan najbliži %s. danu";
    };
    hr.prototype.commaMonthX0ThroughMonthX1 = function () {
        return null;
    };
    hr.prototype.commaYearX0ThroughYearX1 = function () {
        return null;
    };
    hr.prototype.atX0MinutesPastTheHourGt20 = function () {
        return null;
    };
    hr.prototype.atX0SecondsPastTheMinuteGt20 = function () {
        return null;
    };
    hr.prototype.commaStartingX0 = function () {
        return ", počevši od %s";
    };
    hr.prototype.daysOfTheWeek = function () {
        return [
            "Nedjelja",
            "Ponedjeljak",
            "Utorak",
            "Srijeda",
            "Četvrtak",
            "Petak",
            "Subota",
        ];
    };
    hr.prototype.monthsOfTheYear = function () {
        return [
            "siječanj",
            "veljača",
            "ožujak",
            "travanj",
            "svibanj",
            "lipanj",
            "srpanj",
            "kolovoz",
            "rujan",
            "listopad",
            "studeni",
            "prosinac",
        ];
    };
    hr.prototype.onTheHour = function () {
        return "u puni sat";
    };
    return hr;
}());
hr_exports.hr = hr;


(cronstrue__WEBPACK_IMPORTED_MODULE_0___default().locales)["hr"] = new hr();

/******/ 	return __webpack_exports__;
/******/ })()
;
});