declare const require: any;
