type BootAsyncSchema = {};
