import { Tree } from '@nrwl/devkit';
import { MfGeneratorSchema } from './schema';
export default function (host: Tree, options: MfGeneratorSchema): Promise<void>;
