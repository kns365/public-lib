export declare class CronEditorModule {
}
