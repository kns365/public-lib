(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('@angular/forms'), require('@angular/common')) :
    typeof define === 'function' && define.amd ? define('cron-editor', ['exports', '@angular/core', '@angular/forms', '@angular/common'], factory) :
    (factory((global['cron-editor'] = {}),global.ng.core,global.ng.forms,global.ng.common));
}(this, (function (exports,core,forms,common) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m)
            return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
                ar.push(r.value);
        }
        catch (error) {
            e = { error: error };
        }
        finally {
            try {
                if (r && !r.done && (m = i["return"]))
                    m.call(i);
            }
            finally {
                if (e)
                    throw e.error;
            }
        }
        return ar;
    }
    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /** @type {?} */
    var Days = {
        'SUN': 'Sunday',
        'MON': 'Monday',
        'TUE': 'Tuesday',
        'WED': 'Wednesday',
        'THU': 'Thursday',
        'FRI': 'Friday',
        'SAT': 'Saturday'
    };
    /** @type {?} */
    var MonthWeeks = {
        '#1': 'First',
        '#2': 'Second',
        '#3': 'Third',
        '#4': 'Fourth',
        '#5': 'Fifth',
        'L': 'Last'
    };
    /** @enum {number} */
    var Months = {
        January: 1,
        February: 2,
        March: 3,
        April: 4,
        May: 5,
        June: 6,
        July: 7,
        August: 8,
        September: 9,
        October: 10,
        November: 11,
        December: 12,
    };
    Months[Months.January] = 'January';
    Months[Months.February] = 'February';
    Months[Months.March] = 'March';
    Months[Months.April] = 'April';
    Months[Months.May] = 'May';
    Months[Months.June] = 'June';
    Months[Months.July] = 'July';
    Months[Months.August] = 'August';
    Months[Months.September] = 'September';
    Months[Months.October] = 'October';
    Months[Months.November] = 'November';
    Months[Months.December] = 'December';

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    // @dynamic
    var 
    // @dynamic
    Utils = /** @class */ (function () {
        function Utils() {
        }
        /** This returns a range of numbers. Starts from 0 if 'startFrom' is not set */
        /**
         * This returns a range of numbers. Starts from 0 if 'startFrom' is not set
         * @param {?} startFrom
         * @param {?} until
         * @return {?}
         */
        Utils.getRange = /**
         * This returns a range of numbers. Starts from 0 if 'startFrom' is not set
         * @param {?} startFrom
         * @param {?} until
         * @return {?}
         */
            function (startFrom, until) {
                return Array.from({ length: (until + 1 - startFrom) }, function (_, k) { return k + startFrom; });
            };
        return Utils;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var CronEditorComponent = /** @class */ (function () {
        function CronEditorComponent() {
            // the name is an Angular convention, @Input variable name + "Change" suffix
            this.cronChange = new core.EventEmitter();
            this.selectOptions = this.getSelectOptions();
        }
        Object.defineProperty(CronEditorComponent.prototype, "cron", {
            get: /**
             * @return {?}
             */ function () { return this.localCron; },
            set: /**
             * @param {?} value
             * @return {?}
             */ function (value) {
                this.localCron = value;
                this.cronChange.emit(this.localCron);
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @return {?}
         */
        CronEditorComponent.prototype.ngOnInit = /**
         * @return {?}
         */
            function () {
                if (this.options.removeSeconds) {
                    this.options.hideSeconds = true;
                }
                this.state = this.getDefaultState();
                this.handleModelChange(this.cron);
            };
        /**
         * @param {?} changes
         * @return {?}
         */
        CronEditorComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
            function (changes) {
                /** @type {?} */
                var newCron = changes['cron'];
                if (newCron && !newCron.firstChange) {
                    this.handleModelChange(this.cron);
                }
            };
        /**
         * @param {?} tab
         * @return {?}
         */
        CronEditorComponent.prototype.setActiveTab = /**
         * @param {?} tab
         * @return {?}
         */
            function (tab) {
                if (!this.disabled) {
                    this.activeTab = tab;
                    this.regenerateCron();
                }
            };
        /**
         * @param {?} day
         * @return {?}
         */
        CronEditorComponent.prototype.dayDisplay = /**
         * @param {?} day
         * @return {?}
         */
            function (day) {
                return Days[day];
            };
        /**
         * @param {?} monthWeekNumber
         * @return {?}
         */
        CronEditorComponent.prototype.monthWeekDisplay = /**
         * @param {?} monthWeekNumber
         * @return {?}
         */
            function (monthWeekNumber) {
                return MonthWeeks[monthWeekNumber];
            };
        /**
         * @param {?} month
         * @return {?}
         */
        CronEditorComponent.prototype.monthDisplay = /**
         * @param {?} month
         * @return {?}
         */
            function (month) {
                return Months[month];
            };
        /**
         * @param {?} month
         * @return {?}
         */
        CronEditorComponent.prototype.monthDayDisplay = /**
         * @param {?} month
         * @return {?}
         */
            function (month) {
                if (month === 'L') {
                    return 'Last Day';
                }
                else if (month === 'LW') {
                    return 'Last Weekday';
                }
                else if (month === '1W') {
                    return 'First Weekday';
                }
                else {
                    return "" + month + this.getOrdinalSuffix(month) + " day";
                }
            };
        /**
         * @return {?}
         */
        CronEditorComponent.prototype.regenerateCron = /**
         * @return {?}
         */
            function () {
                var _this = this;
                this.isDirty = true;
                switch (this.activeTab) {
                    case 'minutes':
                        this.cron = "0/" + this.state.minutes.minutes + " * 1/1 * ?";
                        if (!this.options.removeSeconds) {
                            this.cron = this.state.minutes.seconds + " " + this.cron;
                        }
                        if (!this.options.removeYears) {
                            this.cron = this.cron + " *";
                        }
                        break;
                    case 'hourly':
                        this.cron = this.state.hourly.minutes + " 0/" + this.state.hourly.hours + " 1/1 * ?";
                        if (!this.options.removeSeconds) {
                            this.cron = this.state.hourly.seconds + " " + this.cron;
                        }
                        if (!this.options.removeYears) {
                            this.cron = this.cron + " *";
                        }
                        break;
                    case 'daily':
                        switch (this.state.daily.subTab) {
                            case 'everyDays':
                                // tslint:disable-next-line:max-line-length
                                this.cron = this.state.daily.everyDays.minutes + " " + this.hourToCron(this.state.daily.everyDays.hours, this.state.daily.everyDays.hourType) + " 1/" + this.state.daily.everyDays.days + " * ?";
                                if (!this.options.removeSeconds) {
                                    this.cron = this.state.daily.everyDays.seconds + " " + this.cron;
                                }
                                if (!this.options.removeYears) {
                                    this.cron = this.cron + " *";
                                }
                                break;
                            case 'everyWeekDay':
                                // tslint:disable-next-line:max-line-length
                                this.cron = this.state.daily.everyWeekDay.minutes + " " + this.hourToCron(this.state.daily.everyWeekDay.hours, this.state.daily.everyWeekDay.hourType) + " ? * MON-FRI";
                                if (!this.options.removeSeconds) {
                                    this.cron = this.state.daily.everyWeekDay.seconds + " " + this.cron;
                                }
                                if (!this.options.removeYears) {
                                    this.cron = this.cron + " *";
                                }
                                break;
                            default:
                                throw new Error('Invalid cron daily subtab selection');
                        }
                        break;
                    case 'weekly':
                        /** @type {?} */
                        var days = this.selectOptions.days
                            .reduce(function (acc, day) { return _this.state.weekly[day] ? acc.concat([day]) : acc; }, [])
                            .join(',');
                        this.cron = this.state.weekly.minutes + " " + this.hourToCron(this.state.weekly.hours, this.state.weekly.hourType) + " ? * " + days;
                        if (!this.options.removeSeconds) {
                            this.cron = this.state.weekly.seconds + " " + this.cron;
                        }
                        if (!this.options.removeYears) {
                            this.cron = this.cron + " *";
                        }
                        break;
                    case 'monthly':
                        switch (this.state.monthly.subTab) {
                            case 'specificDay':
                                /** @type {?} */
                                var day = this.state.monthly.runOnWeekday ? this.state.monthly.specificDay.day + "W" : this.state.monthly.specificDay.day;
                                // tslint:disable-next-line:max-line-length
                                this.cron = this.state.monthly.specificDay.minutes + " " + this.hourToCron(this.state.monthly.specificDay.hours, this.state.monthly.specificDay.hourType) + " " + day + " 1/" + this.state.monthly.specificDay.months + " ?";
                                if (!this.options.removeSeconds) {
                                    this.cron = this.state.monthly.specificDay.seconds + " " + this.cron;
                                }
                                if (!this.options.removeYears) {
                                    this.cron = this.cron + " *";
                                }
                                break;
                            case 'specificWeekDay':
                                // tslint:disable-next-line:max-line-length
                                this.cron = this.state.monthly.specificWeekDay.minutes + " " + this.hourToCron(this.state.monthly.specificWeekDay.hours, this.state.monthly.specificWeekDay.hourType) + " ? " + this.state.monthly.specificWeekDay.startMonth + "/" + this.state.monthly.specificWeekDay.months + " " + this.state.monthly.specificWeekDay.day + this.state.monthly.specificWeekDay.monthWeek;
                                if (!this.options.removeSeconds) {
                                    this.cron = this.state.monthly.specificWeekDay.seconds + " " + this.cron;
                                }
                                if (!this.options.removeYears) {
                                    this.cron = this.cron + " *";
                                }
                                break;
                            default:
                                throw new Error('Invalid cron monthly subtab selection');
                        }
                        break;
                    case 'yearly':
                        switch (this.state.yearly.subTab) {
                            case 'specificMonthDay':
                                // tslint:disable-next-line:max-line-length
                                /** @type {?} */
                                var day = this.state.yearly.runOnWeekday ? this.state.yearly.specificMonthDay.day + "W" : this.state.yearly.specificMonthDay.day;
                                // tslint:disable-next-line:max-line-length
                                this.cron = this.state.yearly.specificMonthDay.minutes + " " + this.hourToCron(this.state.yearly.specificMonthDay.hours, this.state.yearly.specificMonthDay.hourType) + " " + day + " " + this.state.yearly.specificMonthDay.month + " ?";
                                if (!this.options.removeSeconds) {
                                    this.cron = this.state.yearly.specificMonthDay.seconds + " " + this.cron;
                                }
                                if (!this.options.removeYears) {
                                    this.cron = this.cron + " *";
                                }
                                break;
                            case 'specificMonthWeek':
                                // tslint:disable-next-line:max-line-length
                                this.cron = this.state.yearly.specificMonthWeek.minutes + " " + this.hourToCron(this.state.yearly.specificMonthWeek.hours, this.state.yearly.specificMonthWeek.hourType) + " ? " + this.state.yearly.specificMonthWeek.month + " " + this.state.yearly.specificMonthWeek.day + this.state.yearly.specificMonthWeek.monthWeek;
                                if (!this.options.removeSeconds) {
                                    this.cron = this.state.yearly.specificMonthWeek.seconds + " " + this.cron;
                                }
                                if (!this.options.removeYears) {
                                    this.cron = this.cron + " *";
                                }
                                break;
                            default:
                                throw new Error('Invalid cron yearly subtab selection');
                        }
                        break;
                    case 'advanced':
                        this.cron = this.state.advanced.expression;
                        break;
                    default:
                        throw new Error('Invalid cron active tab selection');
                }
            };
        /**
         * @private
         * @param {?} hour
         * @return {?}
         */
        CronEditorComponent.prototype.getAmPmHour = /**
         * @private
         * @param {?} hour
         * @return {?}
         */
            function (hour) {
                return this.options.use24HourTime ? hour : (hour + 11) % 12 + 1;
            };
        /**
         * @private
         * @param {?} hour
         * @return {?}
         */
        CronEditorComponent.prototype.getHourType = /**
         * @private
         * @param {?} hour
         * @return {?}
         */
            function (hour) {
                return this.options.use24HourTime ? undefined : (hour >= 12 ? 'PM' : 'AM');
            };
        /**
         * @private
         * @param {?} hour
         * @param {?} hourType
         * @return {?}
         */
        CronEditorComponent.prototype.hourToCron = /**
         * @private
         * @param {?} hour
         * @param {?} hourType
         * @return {?}
         */
            function (hour, hourType) {
                if (this.options.use24HourTime) {
                    return hour;
                }
                else {
                    return hourType === 'AM' ? (hour === 12 ? 0 : hour) : (hour === 12 ? 12 : hour + 12);
                }
            };
        /**
         * @private
         * @param {?} cron
         * @return {?}
         */
        CronEditorComponent.prototype.handleModelChange = /**
         * @private
         * @param {?} cron
         * @return {?}
         */
            function (cron) {
                var _this = this;
                if (this.isDirty) {
                    this.isDirty = false;
                    return;
                }
                else {
                    this.isDirty = false;
                }
                this.validate(cron);
                /** @type {?} */
                var cronSeven = cron;
                if (this.options.removeSeconds) {
                    cronSeven = "0 " + cron;
                }
                if (this.options.removeYears) {
                    cronSeven = cronSeven + " *";
                }
                var _a = __read(cronSeven.split(' '), 6), seconds = _a[0], minutes = _a[1], hours = _a[2], dayOfMonth = _a[3], month = _a[4], dayOfWeek = _a[5];
                if (cronSeven.match(/\d+ 0\/\d+ \* 1\/1 \* \? \*/)) {
                    this.activeTab = 'minutes';
                    this.state.minutes.minutes = Number(minutes.substring(2));
                    this.state.minutes.seconds = Number(seconds);
                }
                else if (cronSeven.match(/\d+ \d+ 0\/\d+ 1\/1 \* \? \*/)) {
                    this.activeTab = 'hourly';
                    this.state.hourly.hours = Number(hours.substring(2));
                    this.state.hourly.minutes = Number(minutes);
                    this.state.hourly.seconds = Number(seconds);
                }
                else if (cronSeven.match(/\d+ \d+ \d+ 1\/\d+ \* \? \*/)) {
                    this.activeTab = 'daily';
                    this.state.daily.subTab = 'everyDays';
                    this.state.daily.everyDays.days = Number(dayOfMonth.substring(2));
                    /** @type {?} */
                    var parsedHours = Number(hours);
                    this.state.daily.everyDays.hours = this.getAmPmHour(parsedHours);
                    this.state.daily.everyDays.hourType = this.getHourType(parsedHours);
                    this.state.daily.everyDays.minutes = Number(minutes);
                    this.state.daily.everyDays.seconds = Number(seconds);
                }
                else if (cronSeven.match(/\d+ \d+ \d+ \? \* MON-FRI \*/)) {
                    this.activeTab = 'daily';
                    this.state.daily.subTab = 'everyWeekDay';
                    /** @type {?} */
                    var parsedHours = Number(hours);
                    this.state.daily.everyWeekDay.hours = this.getAmPmHour(parsedHours);
                    this.state.daily.everyWeekDay.hourType = this.getHourType(parsedHours);
                    this.state.daily.everyWeekDay.minutes = Number(minutes);
                    this.state.daily.everyWeekDay.seconds = Number(seconds);
                }
                else if (cronSeven.match(/\d+ \d+ \d+ \? \* (MON|TUE|WED|THU|FRI|SAT|SUN)(,(MON|TUE|WED|THU|FRI|SAT|SUN))* \*/)) {
                    this.activeTab = 'weekly';
                    this.selectOptions.days.forEach(function (weekDay) { return _this.state.weekly[weekDay] = false; });
                    dayOfWeek.split(',').forEach(function (weekDay) { return _this.state.weekly[weekDay] = true; });
                    /** @type {?} */
                    var parsedHours = Number(hours);
                    this.state.weekly.hours = this.getAmPmHour(parsedHours);
                    this.state.weekly.hourType = this.getHourType(parsedHours);
                    this.state.weekly.minutes = Number(minutes);
                    this.state.weekly.seconds = Number(seconds);
                }
                else if (cronSeven.match(/\d+ \d+ \d+ (\d+|L|LW|1W) 1\/\d+ \? \*/)) {
                    this.activeTab = 'monthly';
                    this.state.monthly.subTab = 'specificDay';
                    if (dayOfMonth.indexOf('W') !== -1) {
                        this.state.monthly.specificDay.day = dayOfMonth.charAt(0);
                        this.state.monthly.runOnWeekday = true;
                    }
                    else {
                        this.state.monthly.specificDay.day = dayOfMonth;
                    }
                    this.state.monthly.specificDay.months = Number(month.substring(2));
                    /** @type {?} */
                    var parsedHours = Number(hours);
                    this.state.monthly.specificDay.hours = this.getAmPmHour(parsedHours);
                    this.state.monthly.specificDay.hourType = this.getHourType(parsedHours);
                    this.state.monthly.specificDay.minutes = Number(minutes);
                    this.state.monthly.specificDay.seconds = Number(seconds);
                }
                else if (cronSeven.match(/\d+ \d+ \d+ \? \d+\/\d+ (MON|TUE|WED|THU|FRI|SAT|SUN)((#[1-5])|L) \*/)) {
                    /** @type {?} */
                    var day = dayOfWeek.substr(0, 3);
                    /** @type {?} */
                    var monthWeek = dayOfWeek.substr(3);
                    this.activeTab = 'monthly';
                    this.state.monthly.subTab = 'specificWeekDay';
                    this.state.monthly.specificWeekDay.monthWeek = monthWeek;
                    this.state.monthly.specificWeekDay.day = day;
                    if (month.indexOf('/') !== -1) {
                        var _b = __read(month.split('/').map(Number), 2), startMonth = _b[0], months = _b[1];
                        this.state.monthly.specificWeekDay.months = months;
                        this.state.monthly.specificWeekDay.startMonth = startMonth;
                    }
                    /** @type {?} */
                    var parsedHours = Number(hours);
                    this.state.monthly.specificWeekDay.hours = this.getAmPmHour(parsedHours);
                    this.state.monthly.specificWeekDay.hourType = this.getHourType(parsedHours);
                    this.state.monthly.specificWeekDay.minutes = Number(minutes);
                    this.state.monthly.specificWeekDay.seconds = Number(seconds);
                }
                else if (cronSeven.match(/\d+ \d+ \d+ (\d+|L|LW|1W) \d+ \? \*/)) {
                    this.activeTab = 'yearly';
                    this.state.yearly.subTab = 'specificMonthDay';
                    this.state.yearly.specificMonthDay.month = Number(month);
                    if (dayOfMonth.indexOf('W') !== -1) {
                        this.state.yearly.specificMonthDay.day = dayOfMonth.charAt(0);
                        this.state.yearly.runOnWeekday = true;
                    }
                    else {
                        this.state.yearly.specificMonthDay.day = dayOfMonth;
                    }
                    /** @type {?} */
                    var parsedHours = Number(hours);
                    this.state.yearly.specificMonthDay.hours = this.getAmPmHour(parsedHours);
                    this.state.yearly.specificMonthDay.hourType = this.getHourType(parsedHours);
                    this.state.yearly.specificMonthDay.minutes = Number(minutes);
                    this.state.yearly.specificMonthDay.seconds = Number(seconds);
                }
                else if (cronSeven.match(/\d+ \d+ \d+ \? \d+ (MON|TUE|WED|THU|FRI|SAT|SUN)((#[1-5])|L) \*/)) {
                    /** @type {?} */
                    var day = dayOfWeek.substr(0, 3);
                    /** @type {?} */
                    var monthWeek = dayOfWeek.substr(3);
                    this.activeTab = 'yearly';
                    this.state.yearly.subTab = 'specificMonthWeek';
                    this.state.yearly.specificMonthWeek.monthWeek = monthWeek;
                    this.state.yearly.specificMonthWeek.day = day;
                    this.state.yearly.specificMonthWeek.month = Number(month);
                    /** @type {?} */
                    var parsedHours = Number(hours);
                    this.state.yearly.specificMonthWeek.hours = this.getAmPmHour(parsedHours);
                    this.state.yearly.specificMonthWeek.hourType = this.getHourType(parsedHours);
                    this.state.yearly.specificMonthWeek.minutes = Number(minutes);
                    this.state.yearly.specificMonthWeek.seconds = Number(seconds);
                }
                else {
                    this.activeTab = 'advanced';
                    this.state.advanced.expression = cron;
                }
            };
        /**
         * @private
         * @param {?} cron
         * @return {?}
         */
        CronEditorComponent.prototype.validate = /**
         * @private
         * @param {?} cron
         * @return {?}
         */
            function (cron) {
                this.state.validation.isValid = false;
                this.state.validation.errorMessage = '';
                if (!cron) {
                    this.state.validation.errorMessage = 'Cron expression cannot be null';
                    return;
                }
                /** @type {?} */
                var cronParts = cron.split(' ');
                /** @type {?} */
                var expected = 5;
                if (!this.options.removeSeconds) {
                    expected++;
                }
                if (!this.options.removeYears) {
                    expected++;
                }
                if (cronParts.length !== expected) {
                    this.state.validation.errorMessage = "Invalid cron expression, there must be " + expected + " segments";
                    return;
                }
                this.state.validation.isValid = true;
                return;
            };
        /**
         * @private
         * @return {?}
         */
        CronEditorComponent.prototype.getDefaultAdvancedCronExpression = /**
         * @private
         * @return {?}
         */
            function () {
                if (this.options.removeSeconds && !this.options.removeYears) {
                    return '15 10 L-2 * ? 2019';
                }
                if (!this.options.removeSeconds && this.options.removeYears) {
                    return '0 15 10 L-2 * ?';
                }
                if (this.options.removeSeconds && this.options.removeYears) {
                    return '15 10 L-2 * ?';
                }
                return '0 15 10 L-2 * ? 2019';
            };
        /**
         * @private
         * @return {?}
         */
        CronEditorComponent.prototype.getDefaultState = /**
         * @private
         * @return {?}
         */
            function () {
                var _a = __read(this.options.defaultTime.split(':').map(Number), 3), defaultHours = _a[0], defaultMinutes = _a[1], defaultSeconds = _a[2];
                return {
                    minutes: {
                        minutes: 1,
                        seconds: 0
                    },
                    hourly: {
                        hours: 1,
                        minutes: 0,
                        seconds: 0
                    },
                    daily: {
                        subTab: 'everyDays',
                        everyDays: {
                            days: 1,
                            hours: this.getAmPmHour(defaultHours),
                            minutes: defaultMinutes,
                            seconds: defaultSeconds,
                            hourType: this.getHourType(defaultHours)
                        },
                        everyWeekDay: {
                            hours: this.getAmPmHour(defaultHours),
                            minutes: defaultMinutes,
                            seconds: defaultSeconds,
                            hourType: this.getHourType(defaultHours)
                        }
                    },
                    weekly: {
                        MON: true,
                        TUE: false,
                        WED: false,
                        THU: false,
                        FRI: false,
                        SAT: false,
                        SUN: false,
                        hours: this.getAmPmHour(defaultHours),
                        minutes: defaultMinutes,
                        seconds: defaultSeconds,
                        hourType: this.getHourType(defaultHours)
                    },
                    monthly: {
                        subTab: 'specificDay',
                        runOnWeekday: false,
                        specificDay: {
                            day: '1',
                            months: 1,
                            hours: this.getAmPmHour(defaultHours),
                            minutes: defaultMinutes,
                            seconds: defaultSeconds,
                            hourType: this.getHourType(defaultHours)
                        },
                        specificWeekDay: {
                            monthWeek: '#1',
                            day: 'MON',
                            startMonth: 1,
                            months: 1,
                            hours: this.getAmPmHour(defaultHours),
                            minutes: defaultMinutes,
                            seconds: defaultSeconds,
                            hourType: this.getHourType(defaultHours)
                        }
                    },
                    yearly: {
                        subTab: 'specificMonthDay',
                        runOnWeekday: false,
                        specificMonthDay: {
                            month: 1,
                            day: '1',
                            hours: this.getAmPmHour(defaultHours),
                            minutes: defaultMinutes,
                            seconds: defaultSeconds,
                            hourType: this.getHourType(defaultHours)
                        },
                        specificMonthWeek: {
                            monthWeek: '#1',
                            day: 'MON',
                            month: 1,
                            hours: this.getAmPmHour(defaultHours),
                            minutes: defaultMinutes,
                            seconds: defaultSeconds,
                            hourType: this.getHourType(defaultHours)
                        }
                    },
                    advanced: {
                        expression: this.getDefaultAdvancedCronExpression()
                    },
                    validation: {
                        isValid: true,
                        errorMessage: ''
                    }
                };
            };
        /**
         * @private
         * @param {?} value
         * @return {?}
         */
        CronEditorComponent.prototype.getOrdinalSuffix = /**
         * @private
         * @param {?} value
         * @return {?}
         */
            function (value) {
                if (value.length > 1) {
                    /** @type {?} */
                    var secondToLastDigit = value.charAt(value.length - 2);
                    if (secondToLastDigit === '1') {
                        return 'th';
                    }
                }
                /** @type {?} */
                var lastDigit = value.charAt(value.length - 1);
                switch (lastDigit) {
                    case '1':
                        return 'st';
                    case '2':
                        return 'nd';
                    case '3':
                        return 'rd';
                    default:
                        return 'th';
                }
            };
        /**
         * @private
         * @return {?}
         */
        CronEditorComponent.prototype.getSelectOptions = /**
         * @private
         * @return {?}
         */
            function () {
                return {
                    months: Utils.getRange(1, 12),
                    monthWeeks: ['#1', '#2', '#3', '#4', '#5', 'L'],
                    days: ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'],
                    minutes: Utils.getRange(0, 59),
                    fullMinutes: Utils.getRange(0, 59),
                    seconds: Utils.getRange(0, 59),
                    hours: Utils.getRange(1, 23),
                    monthDays: Utils.getRange(1, 31),
                    monthDaysWithLasts: __spread(Utils.getRange(1, 31).map(String), ['L']),
                    hourTypes: ['AM', 'PM']
                };
            };
        CronEditorComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'cron-editor',
                        template: "<!-- Tabs -->\r\n<ul class=\"nav nav-tabs tab-nav\" role=\"tablist\">\r\n    <li [ngClass]=\"{'active': activeTab === 'minutes'}\" *ngIf=\"!options.hideMinutesTab\">\r\n        <a aria-controls=\"minutes\" role=\"tab\" data-toggle=\"tab\" (click)=\"setActiveTab('minutes')\">\r\n            Minutes\r\n        </a>\r\n    </li>\r\n\r\n    <li role=\"presentation\" *ngIf=\"!options.hideHourlyTab\" [ngClass]=\"{'active': activeTab === 'hourly'}\">\r\n        <a aria-controls=\"hourly\" role=\"tab\" data-toggle=\"tab\" (click)=\"setActiveTab('hourly')\">\r\n            Hourly\r\n        </a>\r\n    </li>\r\n\r\n    <li role=\"presentation\" *ngIf=\"!options.hideDailyTab\" [ngClass]=\"{'active': activeTab === 'daily'}\">\r\n        <a aria-controls=\"daily\" role=\"tab\" data-toggle=\"tab\" (click)=\"setActiveTab('daily')\">\r\n            Daily\r\n        </a>\r\n    </li>\r\n\r\n    <li role=\"presentation\" *ngIf=\"!options.hideWeeklyTab\" [ngClass]=\"{'active': activeTab === 'weekly'}\">\r\n        <a aria-controls=\"weekly\" role=\"tab\" data-toggle=\"tab\" (click)=\"setActiveTab('weekly')\">\r\n            Weekly\r\n        </a>\r\n    </li>\r\n\r\n    <li role=\"presentation\" *ngIf=\"!options.hideMonthlyTab\" [ngClass]=\"{'active': activeTab === 'monthly'}\">\r\n        <a aria-controls=\"monthly\" role=\"tab\" data-toggle=\"tab\" (click)=\"setActiveTab('monthly')\">\r\n            Monthly\r\n        </a>\r\n    </li>\r\n\r\n    <li role=\"presentation\" *ngIf=\"!options.hideYearlyTab\" [ngClass]=\"{'active': activeTab === 'yearly'}\">\r\n        <a aria-controls=\"yearly\" role=\"tab\" data-toggle=\"tab\" (click)=\"setActiveTab('yearly')\">\r\n            Yearly\r\n        </a>\r\n    </li>\r\n\r\n    <li role=\"presentation\" *ngIf=\"!options.hideAdvancedTab\" [ngClass]=\"{'active': activeTab === 'advanced'}\">\r\n        <a aria-controls=\"advanced\" role=\"tab\" data-toggle=\"tab\" (click)=\"setActiveTab('advanced')\">\r\n            Advanced\r\n        </a>\r\n    </li>\r\n</ul>\r\n\r\n<!-- Tab content -->\r\n<div class=\"cron-editor-container\">\r\n    <div class=\"row\">\r\n        <div class=\"col-xs-12\">\r\n            <div class=\"tab-content\">\r\n                <!-- Minutes-->\r\n                <div class=\"tab-pane\" *ngIf=\"!options.hideMinutesTab\" [ngClass]=\"{'active': activeTab === 'minutes'}\">\r\n                    <div class=\"well well-small\">\r\n                        Every\r\n                        <select class=\"minutes\" [disabled]=\"disabled || activeTab !== 'minutes'\" (change)=\"regenerateCron()\"\r\n                            [(ngModel)]=\"state.minutes.minutes\" [ngClass]=\"options.formSelectClass\">\r\n                            <option *ngFor=\"let minute of selectOptions.minutes\" [ngValue]=\"minute\">\r\n                                {{minute}}\r\n                            </option>\r\n                        </select> minute(s)\r\n                        <span *ngIf=\"!options.hideSeconds\">on second</span>\r\n                        <select class=\"seconds\" *ngIf=\"!options.hideSeconds\" [disabled]=\"disabled || activeTab !== 'minutes'\"\r\n                            (change)=\"regenerateCron()\" [(ngModel)]=\"state.minutes.seconds\" [ngClass]=\"options.formSelectClass\">\r\n                            <option *ngFor=\"let second of selectOptions.seconds\" [ngValue]=\"second\">\r\n                                {{second}}\r\n                            </option>\r\n                        </select>\r\n                    </div>\r\n                </div>\r\n\r\n                <!-- Hourly-->\r\n                <div class=\"tab-pane\" *ngIf=\"!options.hideHourlyTab\" [ngClass]=\"{'active': activeTab === 'hourly'}\">\r\n                    <div class=\"well well-small\">\r\n                        Every\r\n                        <select class=\"hours\" [disabled]=\"disabled || activeTab !== 'hourly'\" (change)=\"regenerateCron()\"\r\n                            [(ngModel)]=\"state.hourly.hours\" [ngClass]=\"options.formSelectClass\">\r\n                            <option *ngFor=\"let hour of selectOptions.hours\" [ngValue]=\"hour\">\r\n                                {{hour}}\r\n                            </option>\r\n                        </select> hour(s) on minute\r\n                        <select class=\"minutes\" [disabled]=\"disabled || activeTab !== 'hourly'\" (change)=\"regenerateCron()\"\r\n                            [(ngModel)]=\"state.hourly.minutes\" [ngClass]=\"options.formSelectClass\">\r\n                            <option *ngFor=\"let minute of selectOptions.fullMinutes\" [ngValue]=\"minute\">\r\n                                {{minute}}\r\n                            </option>\r\n                        </select>\r\n                        <span *ngIf=\"!options.hideSeconds\">and second</span>\r\n                        <select class=\"seconds\" *ngIf=\"!options.hideSeconds\" [disabled]=\"disabled || activeTab !== 'hourly'\"\r\n                            (change)=\"regenerateCron()\" [(ngModel)]=\"state.hourly.seconds\" [ngClass]=\"options.formSelectClass\">\r\n                            <option *ngFor=\"let second of selectOptions.seconds\" [ngValue]=\"second\">\r\n                                {{second}}\r\n                            </option>\r\n                        </select>\r\n                    </div>\r\n                </div>\r\n\r\n                <!-- Daily-->\r\n                <div class=\"tab-pane\" *ngIf=\"!options.hideDailyTab\" [ngClass]=\"{'active': activeTab === 'daily'}\">\r\n                    <div class=\"well well-small\">\r\n                        <input type=\"radio\" name=\"daily-radio\" value=\"everyDays\" [disabled]=\"disabled\" (change)=\"regenerateCron()\"\r\n                            [(ngModel)]=\"state.daily.subTab\" value=\"everyDays\" [disabled]=\"disabled\" (change)=\"regenerateCron()\"\r\n                            [(ngModel)]=\"state.daily.subTab\" [ngClass]=\"state.formRadioClass\" checked=\"checked\">\r\n                        Every\r\n                        <select class=\"days\" [disabled]=\"disabled || activeTab !== 'daily' || state.daily.subTab !== 'everyDays'\"\r\n                            (change)=\"regenerateCron()\" [(ngModel)]=\"state.daily.everyDays.days\" [ngClass]=\"options.formSelectClass\">\r\n                            <option *ngFor=\"let monthDay of selectOptions.monthDays\" [ngValue]=\"monthDay\">\r\n                                {{monthDay}}\r\n                            </option>\r\n                        </select> day(s) at\r\n\r\n                        <cron-time-picker [disabled]=\"disabled || activeTab !== 'daily' || state.daily.subTab !== 'everyDays'\"\r\n                            (change)=\"regenerateCron()\" [(time)]=\"state.daily.everyDays\" [selectClass]=\"options.formSelectClass\"\r\n                            [use24HourTime]=\"options.use24HourTime\" [hideSeconds]=\"options.hideSeconds\">\r\n                        </cron-time-picker>\r\n                    </div>\r\n\r\n                    <div class=\"well well-small\">\r\n                        <input type=\"radio\" name=\"daily-radio\" value=\"everyWeekDay\" [disabled]=\"disabled\" (change)=\"regenerateCron()\"\r\n                            [(ngModel)]=\"state.daily.subTab\" [ngClass]=\"state.formRadioClass\"> Every working day at\r\n                        <cron-time-picker [disabled]=\"disabled || activeTab !== 'daily' || state.daily.subTab !== 'everyWeekDay'\"\r\n                            (change)=\"regenerateCron()\" [(time)]=\"state.daily.everyWeekDay\" [selectClass]=\"options.formSelectClass\"\r\n                            [use24HourTime]=\"options.use24HourTime\" [hideSeconds]=\"options.hideSeconds\">\r\n                        </cron-time-picker>\r\n                    </div>\r\n                </div>\r\n\r\n                <!-- Weekly-->\r\n                <div class=\"tab-pane\" *ngIf=\"!options.hideWeeklyTab\" [ngClass]=\"{'active': activeTab === 'weekly'}\">\r\n                    <div class=\"well well-small\">\r\n                        <div class=\"row\">\r\n                            <div class=\"col-sm-6\">\r\n                                <label class=\"advanced-cron-editor-label\"><input type=\"checkbox\" [disabled]=\"disabled || activeTab !== 'weekly'\" (change)=\"regenerateCron()\"\r\n                                    [(ngModel)]=\"state.weekly.MON\" [ngClass]=\"options.formCheckboxClass\"> Monday</label>\r\n                            </div>\r\n                            <div class=\"col-sm-6\">\r\n                                <label class=\"advanced-cron-editor-label\"><input type=\"checkbox\" [disabled]=\"disabled || activeTab !== 'weekly'\" (change)=\"regenerateCron()\"\r\n                                    [(ngModel)]=\"state.weekly.TUE\" [ngClass]=\"options.formCheckboxClass\"> Tuesday</label>\r\n                            </div>\r\n                            <div class=\"col-sm-6\">\r\n                                <label class=\"advanced-cron-editor-label\"><input type=\"checkbox\" [disabled]=\"disabled || activeTab !== 'weekly'\" (change)=\"regenerateCron()\"\r\n                                    [(ngModel)]=\"state.weekly.WED\" [ngClass]=\"options.formCheckboxClass\"> Wednesday</label>\r\n                            </div>\r\n                            <div class=\"col-sm-6\">\r\n                                <label class=\"advanced-cron-editor-label\"><input type=\"checkbox\" [disabled]=\"disabled || activeTab !== 'weekly'\" (change)=\"regenerateCron()\"\r\n                                    [(ngModel)]=\"state.weekly.THU\" [ngClass]=\"options.formCheckboxClass\"> Thursday</label>\r\n                            </div>\r\n                            <div class=\"col-sm-6\">\r\n                                <label class=\"advanced-cron-editor-label\"><input type=\"checkbox\" [disabled]=\"disabled || activeTab !== 'weekly'\" (change)=\"regenerateCron()\"\r\n                                    [(ngModel)]=\"state.weekly.FRI\" [ngClass]=\"options.formCheckboxClass\"> Friday</label>\r\n                            </div>\r\n                            <div class=\"col-sm-6\">\r\n                                <label class=\"advanced-cron-editor-label\"><input type=\"checkbox\" [disabled]=\"disabled || activeTab !== 'weekly'\" (change)=\"regenerateCron()\"\r\n                                    [(ngModel)]=\"state.weekly.SAT\" [ngClass]=\"options.formCheckboxClass\"> Saturday</label>\r\n                            </div>\r\n                            <div class=\"col-sm-6\">\r\n                                <label class=\"advanced-cron-editor-label\"><input type=\"checkbox\" [disabled]=\"disabled || activeTab !== 'weekly'\" (change)=\"regenerateCron()\"\r\n                                    [(ngModel)]=\"state.weekly.SUN\" [ngClass]=\"options.formCheckboxClass\"> Sunday</label>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"row\">\r\n                            <div class=\"col-sm-6\">\r\n                                at\r\n                                <cron-time-picker [disabled]=\"disabled || activeTab !== 'weekly'\" (change)=\"regenerateCron()\"\r\n                                    [(time)]=\"state.weekly\" [selectClass]=\"options.formSelectClass\" [use24HourTime]=\"options.use24HourTime\"\r\n                                    [hideSeconds]=\"options.hideSeconds\">\r\n                                </cron-time-picker>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n\r\n                </div>\r\n\r\n                <!-- Monthly-->\r\n                <div class=\"tab-pane\" *ngIf=\"!options.hideMonthlyTab\" [ngClass]=\"{'active': activeTab === 'monthly'}\">\r\n                    <div class=\"well well-small\">\r\n                        <input type=\"radio\" name=\"monthly-radio\" value=\"specificDay\" [disabled]=\"disabled\" (change)=\"regenerateCron()\"\r\n                            [(ngModel)]=\"state.monthly.subTab\" [ngClass]=\"state.formRadioClass\"> On the\r\n                        <select class=\"month-days\" [disabled]=\"disabled || activeTab !== 'monthly' || state.monthly.subTab !== 'specificDay'\"\r\n                            (change)=\"regenerateCron()\" [(ngModel)]=\"state.monthly.specificDay.day\" [ngClass]=\"options.formSelectClass\">\r\n                            <option *ngFor=\"let monthDaysWithLast of selectOptions.monthDaysWithLasts\" [ngValue]=\"monthDaysWithLast\">\r\n                                {{monthDayDisplay(monthDaysWithLast)}}\r\n                            </option>\r\n                        </select> of every\r\n                        <select class=\"months-small\" [disabled]=\"disabled || activeTab !== 'monthly' || state.monthly.subTab !== 'specificDay'\"\r\n                            (change)=\"regenerateCron()\" [(ngModel)]=\"state.monthly.specificDay.months\" [ngClass]=\"options.formSelectClass\">\r\n                            <option *ngFor=\"let month of selectOptions.months\" [ngValue]=\"month\">\r\n                                {{month}}\r\n                            </option>\r\n                        </select> month(s) at\r\n                        <cron-time-picker [disabled]=\"disabled || activeTab !== 'monthly' || state.monthly.subTab !== 'specificDay'\"\r\n                            (change)=\"regenerateCron()\" [(time)]=\"state.monthly.specificDay\" [selectClass]=\"options.formSelectClass\"\r\n                            [use24HourTime]=\"options.use24HourTime\" [hideSeconds]=\"options.hideSeconds\">\r\n                        </cron-time-picker>&nbsp;\r\n                        <label class=\"advanced-cron-editor-label\"><input type=\"checkbox\" [disabled]=\"disabled || activeTab !== 'monthly' || state.monthly.subTab !== 'specificDay'\" \r\n                            (change)=\"regenerateCron()\" [(ngModel)]=\"state.monthly.runOnWeekday\" [ngClass]=\"options.formCheckboxClass\"> during the nearest weekday</label>\r\n                    </div>\r\n                    <div class=\"well well-small\">\r\n                        <input type=\"radio\" name=\"monthly-radio\" value=\"specificWeekDay\" [disabled]=\"disabled\" (change)=\"regenerateCron()\"\r\n                            [(ngModel)]=\"state.monthly.subTab\" [ngClass]=\"state.formRadioClass\">\r\n                        On the\r\n                        <select class=\"day-order-in-month\" [disabled]=\"disabled || activeTab !== 'monthly' || state.monthly.subTab !== 'specificWeekDay'\"\r\n                            (change)=\"regenerateCron()\" [(ngModel)]=\"state.monthly.specificWeekDay.monthWeek\" [ngClass]=\"options.formSelectClass\">\r\n                            <option *ngFor=\"let monthWeek of selectOptions.monthWeeks\" [ngValue]=\"monthWeek\">\r\n                                {{monthWeekDisplay(monthWeek)}}\r\n                            </option>\r\n                        </select>\r\n                        <select class=\"week-days\" [disabled]=\"disabled || activeTab !== 'monthly' || state.monthly.subTab !== 'specificWeekDay'\"\r\n                            (change)=\"regenerateCron()\" [(ngModel)]=\"state.monthly.specificWeekDay.day\" [ngClass]=\"options.formSelectClass\">\r\n                            <option *ngFor=\"let day of selectOptions.days\" [ngValue]=\"day\">\r\n                                {{dayDisplay(day)}}\r\n                            </option>\r\n                        </select> of every\r\n                        <select class=\"months-small\" [disabled]=\"disabled || activeTab !== 'monthly' || state.monthly.subTab !== 'specificWeekDay'\"\r\n                            (change)=\"regenerateCron()\" [(ngModel)]=\"state.monthly.specificWeekDay.months\" [ngClass]=\"options.formSelectClass\">\r\n                            <option *ngFor=\"let month of selectOptions.months\" [ngValue]=\"month\">\r\n                                {{month}}\r\n                            </option>\r\n                        </select> month(s) starting in\r\n                        <select class=\"months\" [disabled]=\"disabled || activeTab !== 'monthly' || state.monthly.subTab !== 'specificWeekDay'\"\r\n                            (change)=\"regenerateCron()\" [(ngModel)]=\"state.monthly.specificWeekDay.startMonth\" [ngClass]=\"options.formSelectClass\">\r\n                            <option *ngFor=\"let month of selectOptions.months\" [ngValue]=\"month\">\r\n                                {{monthDisplay(month)}}\r\n                            </option>\r\n                        </select>\r\n                        \r\n                        at\r\n                        <cron-time-picker [disabled]=\"disabled || activeTab !== 'monthly' || state.monthly.subTab !== 'specificWeekDay'\"\r\n                            (change)=\"regenerateCron()\" [(time)]=\"state.monthly.specificWeekDay\" [selectClass]=\"options.formSelectClass\"\r\n                            [use24HourTime]=\"options.use24HourTime\" [hideSeconds]=\"options.hideSeconds\">\r\n                        </cron-time-picker>\r\n                    </div>\r\n                </div>\r\n\r\n                <!-- Yearly-->\r\n                <div class=\"tab-pane\" *ngIf=\"!options.hideYearlyTab\" [ngClass]=\"{'active': activeTab === 'yearly'}\">\r\n                    <div class=\"well well-small\">\r\n                        <input type=\"radio\" name=\"yearly-radio\" value=\"specificMonthDay\" [disabled]=\"disabled\" (change)=\"regenerateCron()\"\r\n                            [(ngModel)]=\"state.yearly.subTab\" [ngClass]=\"state.formRadioClass\">\r\n                        Every\r\n                        <select class=\"months\" [disabled]=\"disabled || activeTab !== 'yearly' || state.yearly.subTab !== 'specificMonthDay'\"\r\n                            (change)=\"regenerateCron()\" [(ngModel)]=\"state.yearly.specificMonthDay.month\" [ngClass]=\"options.formSelectClass\">\r\n                            <option *ngFor=\"let month of selectOptions.months\" [ngValue]=\"month\">\r\n                                {{monthDisplay(month)}}\r\n                            </option>\r\n                        </select> on the\r\n                        <select class=\"month-days\" [disabled]=\"disabled || activeTab !== 'yearly' || state.yearly.subTab !== 'specificMonthDay'\"\r\n                            (change)=\"regenerateCron()\" [(ngModel)]=\"state.yearly.specificMonthDay.day\" [ngClass]=\"options.formSelectClass\">\r\n                            <option *ngFor=\"let monthDaysWithLast of selectOptions.monthDaysWithLasts\" [ngValue]=\"monthDaysWithLast\">\r\n                                {{monthDayDisplay(monthDaysWithLast)}}\r\n                            </option>\r\n                        </select> at\r\n                        <cron-time-picker [disabled]=\"disabled || activeTab !== 'yearly' || state.yearly.subTab !== 'specificMonthDay'\"\r\n                            (change)=\"regenerateCron()\" [(time)]=\"state.yearly.specificMonthDay\" [selectClass]=\"options.formSelectClass\"\r\n                            [use24HourTime]=\"options.use24HourTime\" [hideSeconds]=\"options.hideSeconds\">\r\n                        </cron-time-picker>&nbsp;\r\n                        <label class=\"advanced-cron-editor-label\"><input type=\"checkbox\" (change)=\"regenerateCron()\"\r\n                        [(ngModel)]=\"state.yearly.runOnWeekday\" [ngClass]=\"options.formCheckboxClass\"> during the nearest weekday</label>\r\n                    </div>\r\n                    <div class=\"well well-small\">\r\n                        <input type=\"radio\" name=\"yearly-radio\" value=\"specificMonthWeek\" [disabled]=\"disabled\"\r\n                            (change)=\"regenerateCron()\" [(ngModel)]=\"state.yearly.subTab\" [ngClass]=\"state.formRadioClass\">\r\n                        On the\r\n                        <select class=\"day-order-in-month\" [disabled]=\"disabled || activeTab !== 'yearly' || state.yearly.subTab !== 'specificMonthWeek'\"\r\n                            (change)=\"regenerateCron()\" [(ngModel)]=\"state.yearly.specificMonthWeek.monthWeek\"\r\n                            [ngClass]=\"options.formSelectClass\">\r\n                            <option *ngFor=\"let monthWeek of selectOptions.monthWeeks\" [ngValue]=\"monthWeek\">\r\n                                {{monthWeekDisplay(monthWeek)}}\r\n                            </option>\r\n                        </select>\r\n                        <select class=\"week-days\" [disabled]=\"disabled || activeTab !== 'yearly' || state.yearly.subTab !== 'specificMonthWeek'\"\r\n                            (change)=\"regenerateCron()\" [(ngModel)]=\"state.yearly.specificMonthWeek.day\" [ngClass]=\"options.formSelectClass\">\r\n                            <option *ngFor=\"let day of selectOptions.days\" [ngValue]=\"day\">\r\n                                {{dayDisplay(day)}}\r\n                            </option>\r\n                        </select> of\r\n                        <select class=\"months\" [disabled]=\"disabled || activeTab !== 'yearly' || state.yearly.subTab !== 'specificMonthWeek'\"\r\n                            (change)=\"regenerateCron()\" [(ngModel)]=\"state.yearly.specificMonthWeek.month\" [ngClass]=\"options.formSelectClass\">\r\n                            <option *ngFor=\"let month of selectOptions.months\" [ngValue]=\"month\">\r\n                                {{monthDisplay(month)}}\r\n                            </option>\r\n                        </select> at\r\n                        <cron-time-picker [disabled]=\"disabled || activeTab !== 'yearly' || state.yearly.subTab !== 'specificMonthWeek'\"\r\n                            (change)=\"regenerateCron()\" [(time)]=\"state.yearly.specificMonthWeek\" [selectClass]=\"options.formSelectClass\"\r\n                            [use24HourTime]=\"options.use24HourTime\" [hideSeconds]=\"options.hideSeconds\">\r\n                        </cron-time-picker>\r\n                    </div>\r\n                </div>\r\n\r\n                <!-- Advanced-->\r\n                <div class=\"tab-pane\" *ngIf=\"!options.hideAdvancedTab\" [ngClass]=\"{'active': activeTab === 'advanced'}\">\r\n                    Cron Expression\r\n                    <input type=\"text\" class=\"advanced-cron-editor-input\" ng-disabled=\"disabled || activeTab !== 'advanced'\"\r\n                        (change)=\"regenerateCron()\" [(ngModel)]=\"state.advanced.expression\" [ngClass]=\"options.formInputClass\">\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n    <div class=\"row\" *ngIf=\"!state.validation.isValid\">\r\n        <code>{{state.validation.errorMessage}}</code>\r\n    </div>\r\n</div>",
                        styles: [".cron-editor-container{margin-top:10px}.cron-editor-container .cron-editor-radio{width:20px;display:inline-block}.cron-editor-container .cron-editor-checkbox,.cron-editor-container .cron-editor-input,.cron-editor-container .cron-editor-select{display:inline-block}.cron-editor-container .well-time-wrapper{padding-left:20px}.cron-editor-container .inline-block{display:inline-block}.cron-editor-container .days,.cron-editor-container .hours,.cron-editor-container .minutes,.cron-editor-container .seconds{width:70px}.cron-editor-container .months{width:120px}.cron-editor-container .month-days{width:130px}.cron-editor-container .months-small{width:60px}.cron-editor-container .day-order-in-month{width:95px}.cron-editor-container .week-days{width:120px}.cron-editor-container .advanced-cron-editor-input{width:200px}.cron-editor-container .hour-types{width:70px}.cron-editor-container .advanced-cron-editor-label{font-weight:200}.nav-tabs li a{cursor:pointer}.form-control{height:auto}"]
                    }] }
        ];
        CronEditorComponent.propDecorators = {
            disabled: [{ type: core.Input }],
            options: [{ type: core.Input }],
            cron: [{ type: core.Input }],
            cronChange: [{ type: core.Output }]
        };
        return CronEditorComponent;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var TimePickerComponent = /** @class */ (function () {
        function TimePickerComponent() {
            this.change = new core.EventEmitter();
        }
        /**
         * @return {?}
         */
        TimePickerComponent.prototype.ngOnInit = /**
         * @return {?}
         */
            function () {
                this.hours = this.use24HourTime ? Utils.getRange(0, 23) : Utils.getRange(0, 12);
                this.minutes = Utils.getRange(0, 59);
                this.seconds = Utils.getRange(0, 59);
                this.hourTypes = ['AM', 'PM'];
            };
        TimePickerComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'cron-time-picker',
                        template: "<!-- hour -->\r\n<select class=\"timeFormControl\" (change)=\"change.emit()\" [(ngModel)]=\"time.hours\" [disabled]=\"disabled\" [ngClass]=\"selectClass\">\r\n  <option *ngFor=\"let hour of hours\" [ngValue]=\"hour\">{{hour}}</option>\r\n</select>\r\n\r\n<!-- minute -->\r\n<select class=\"timeFormControl\" (change)=\"change.emit()\" [(ngModel)]=\"time.minutes\" [disabled]=\"disabled\" [ngClass]=\"selectClass\">\r\n  <option *ngFor=\"let minute of minutes\" [ngValue]=\"minute\">{{minute}}</option>\r\n</select>\r\n\r\n<!-- second -->\r\n<select class=\"timeFormControl\" (change)=\"change.emit()\" [(ngModel)]=\"time.seconds\" [disabled]=\"disabled\" *ngIf=\"!hideSeconds\"\r\n  [ngClass]=\"selectClass\">\r\n  <option *ngFor=\"let second of seconds\" [ngValue]=\"second\">{{second}}</option>\r\n</select>\r\n\r\n<!-- am/pm -->\r\n<select class=\"timeFormControl\" (change)=\"change.emit()\" [(ngModel)]=\"time.hourTypes\" [disabled]=\"disabled\" *ngIf=\"!use24HourTime\"\r\n  [ngClass]=\"selectClass\">\r\n  <option *ngFor=\"let hourType of hourTypes\" [ngValue]=\"hourType\">{{hourType}}</option>\r\n</select>",
                        styles: [".timeFormControl{width:70px;display:inline}"]
                    }] }
        ];
        TimePickerComponent.propDecorators = {
            change: [{ type: core.Output }],
            disabled: [{ type: core.Input }],
            time: [{ type: core.Input }],
            selectClass: [{ type: core.Input }],
            use24HourTime: [{ type: core.Input }],
            hideSeconds: [{ type: core.Input }]
        };
        return TimePickerComponent;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var CronEditorModule = /** @class */ (function () {
        function CronEditorModule() {
        }
        CronEditorModule.decorators = [
            { type: core.NgModule, args: [{
                        declarations: [CronEditorComponent, TimePickerComponent],
                        imports: [common.CommonModule, forms.FormsModule],
                        exports: [CronEditorComponent]
                    },] }
        ];
        return CronEditorModule;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    exports.CronEditorComponent = CronEditorComponent;
    exports.CronEditorModule = CronEditorModule;
    exports.ɵa = TimePickerComponent;

    Object.defineProperty(exports, '__esModule', { value: true });

})));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3Jvbi1lZGl0b3IudW1kLmpzLm1hcCIsInNvdXJjZXMiOlsibm9kZV9tb2R1bGVzL3RzbGliL3RzbGliLmVzNi5qcyIsIm5nOi8vY3Jvbi1lZGl0b3IvbGliL2VudW1zLnRzIiwibmc6Ly9jcm9uLWVkaXRvci9saWIvVXRpbHMudHMiLCJuZzovL2Nyb24tZWRpdG9yL2xpYi9jcm9uLWVkaXRvci5jb21wb25lbnQudHMiLCJuZzovL2Nyb24tZWRpdG9yL2xpYi90aW1lLXBpY2tlci90aW1lLXBpY2tlci5jb21wb25lbnQudHMiLCJuZzovL2Nyb24tZWRpdG9yL2xpYi9jcm9uLWVkaXRvci5tb2R1bGUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLyohICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXHJcbkNvcHlyaWdodCAoYykgTWljcm9zb2Z0IENvcnBvcmF0aW9uLiBBbGwgcmlnaHRzIHJlc2VydmVkLlxyXG5MaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpOyB5b3UgbWF5IG5vdCB1c2VcclxudGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuIFlvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGVcclxuTGljZW5zZSBhdCBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcclxuXHJcblRISVMgQ09ERSBJUyBQUk9WSURFRCBPTiBBTiAqQVMgSVMqIEJBU0lTLCBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTllcclxuS0lORCwgRUlUSEVSIEVYUFJFU1MgT1IgSU1QTElFRCwgSU5DTFVESU5HIFdJVEhPVVQgTElNSVRBVElPTiBBTlkgSU1QTElFRFxyXG5XQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgVElUTEUsIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFLFxyXG5NRVJDSEFOVEFCTElUWSBPUiBOT04tSU5GUklOR0VNRU5ULlxyXG5cclxuU2VlIHRoZSBBcGFjaGUgVmVyc2lvbiAyLjAgTGljZW5zZSBmb3Igc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zXHJcbmFuZCBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cclxuKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiogKi9cclxuLyogZ2xvYmFsIFJlZmxlY3QsIFByb21pc2UgKi9cclxuXHJcbnZhciBleHRlbmRTdGF0aWNzID0gZnVuY3Rpb24oZCwgYikge1xyXG4gICAgZXh0ZW5kU3RhdGljcyA9IE9iamVjdC5zZXRQcm90b3R5cGVPZiB8fFxyXG4gICAgICAgICh7IF9fcHJvdG9fXzogW10gfSBpbnN0YW5jZW9mIEFycmF5ICYmIGZ1bmN0aW9uIChkLCBiKSB7IGQuX19wcm90b19fID0gYjsgfSkgfHxcclxuICAgICAgICBmdW5jdGlvbiAoZCwgYikgeyBmb3IgKHZhciBwIGluIGIpIGlmIChiLmhhc093blByb3BlcnR5KHApKSBkW3BdID0gYltwXTsgfTtcclxuICAgIHJldHVybiBleHRlbmRTdGF0aWNzKGQsIGIpO1xyXG59O1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fZXh0ZW5kcyhkLCBiKSB7XHJcbiAgICBleHRlbmRTdGF0aWNzKGQsIGIpO1xyXG4gICAgZnVuY3Rpb24gX18oKSB7IHRoaXMuY29uc3RydWN0b3IgPSBkOyB9XHJcbiAgICBkLnByb3RvdHlwZSA9IGIgPT09IG51bGwgPyBPYmplY3QuY3JlYXRlKGIpIDogKF9fLnByb3RvdHlwZSA9IGIucHJvdG90eXBlLCBuZXcgX18oKSk7XHJcbn1cclxuXHJcbmV4cG9ydCB2YXIgX19hc3NpZ24gPSBmdW5jdGlvbigpIHtcclxuICAgIF9fYXNzaWduID0gT2JqZWN0LmFzc2lnbiB8fCBmdW5jdGlvbiBfX2Fzc2lnbih0KSB7XHJcbiAgICAgICAgZm9yICh2YXIgcywgaSA9IDEsIG4gPSBhcmd1bWVudHMubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XHJcbiAgICAgICAgICAgIHMgPSBhcmd1bWVudHNbaV07XHJcbiAgICAgICAgICAgIGZvciAodmFyIHAgaW4gcykgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChzLCBwKSkgdFtwXSA9IHNbcF07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0O1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIF9fYXNzaWduLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX3Jlc3QocywgZSkge1xyXG4gICAgdmFyIHQgPSB7fTtcclxuICAgIGZvciAodmFyIHAgaW4gcykgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChzLCBwKSAmJiBlLmluZGV4T2YocCkgPCAwKVxyXG4gICAgICAgIHRbcF0gPSBzW3BdO1xyXG4gICAgaWYgKHMgIT0gbnVsbCAmJiB0eXBlb2YgT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyA9PT0gXCJmdW5jdGlvblwiKVxyXG4gICAgICAgIGZvciAodmFyIGkgPSAwLCBwID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhzKTsgaSA8IHAubGVuZ3RoOyBpKyspIGlmIChlLmluZGV4T2YocFtpXSkgPCAwKVxyXG4gICAgICAgICAgICB0W3BbaV1dID0gc1twW2ldXTtcclxuICAgIHJldHVybiB0O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19kZWNvcmF0ZShkZWNvcmF0b3JzLCB0YXJnZXQsIGtleSwgZGVzYykge1xyXG4gICAgdmFyIGMgPSBhcmd1bWVudHMubGVuZ3RoLCByID0gYyA8IDMgPyB0YXJnZXQgOiBkZXNjID09PSBudWxsID8gZGVzYyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IodGFyZ2V0LCBrZXkpIDogZGVzYywgZDtcclxuICAgIGlmICh0eXBlb2YgUmVmbGVjdCA9PT0gXCJvYmplY3RcIiAmJiB0eXBlb2YgUmVmbGVjdC5kZWNvcmF0ZSA9PT0gXCJmdW5jdGlvblwiKSByID0gUmVmbGVjdC5kZWNvcmF0ZShkZWNvcmF0b3JzLCB0YXJnZXQsIGtleSwgZGVzYyk7XHJcbiAgICBlbHNlIGZvciAodmFyIGkgPSBkZWNvcmF0b3JzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSBpZiAoZCA9IGRlY29yYXRvcnNbaV0pIHIgPSAoYyA8IDMgPyBkKHIpIDogYyA+IDMgPyBkKHRhcmdldCwga2V5LCByKSA6IGQodGFyZ2V0LCBrZXkpKSB8fCByO1xyXG4gICAgcmV0dXJuIGMgPiAzICYmIHIgJiYgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRhcmdldCwga2V5LCByKSwgcjtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fcGFyYW0ocGFyYW1JbmRleCwgZGVjb3JhdG9yKSB7XHJcbiAgICByZXR1cm4gZnVuY3Rpb24gKHRhcmdldCwga2V5KSB7IGRlY29yYXRvcih0YXJnZXQsIGtleSwgcGFyYW1JbmRleCk7IH1cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fbWV0YWRhdGEobWV0YWRhdGFLZXksIG1ldGFkYXRhVmFsdWUpIHtcclxuICAgIGlmICh0eXBlb2YgUmVmbGVjdCA9PT0gXCJvYmplY3RcIiAmJiB0eXBlb2YgUmVmbGVjdC5tZXRhZGF0YSA9PT0gXCJmdW5jdGlvblwiKSByZXR1cm4gUmVmbGVjdC5tZXRhZGF0YShtZXRhZGF0YUtleSwgbWV0YWRhdGFWYWx1ZSk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX2F3YWl0ZXIodGhpc0FyZywgX2FyZ3VtZW50cywgUCwgZ2VuZXJhdG9yKSB7XHJcbiAgICByZXR1cm4gbmV3IChQIHx8IChQID0gUHJvbWlzZSkpKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcclxuICAgICAgICBmdW5jdGlvbiBmdWxmaWxsZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3IubmV4dCh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XHJcbiAgICAgICAgZnVuY3Rpb24gcmVqZWN0ZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3JbXCJ0aHJvd1wiXSh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XHJcbiAgICAgICAgZnVuY3Rpb24gc3RlcChyZXN1bHQpIHsgcmVzdWx0LmRvbmUgPyByZXNvbHZlKHJlc3VsdC52YWx1ZSkgOiBuZXcgUChmdW5jdGlvbiAocmVzb2x2ZSkgeyByZXNvbHZlKHJlc3VsdC52YWx1ZSk7IH0pLnRoZW4oZnVsZmlsbGVkLCByZWplY3RlZCk7IH1cclxuICAgICAgICBzdGVwKChnZW5lcmF0b3IgPSBnZW5lcmF0b3IuYXBwbHkodGhpc0FyZywgX2FyZ3VtZW50cyB8fCBbXSkpLm5leHQoKSk7XHJcbiAgICB9KTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fZ2VuZXJhdG9yKHRoaXNBcmcsIGJvZHkpIHtcclxuICAgIHZhciBfID0geyBsYWJlbDogMCwgc2VudDogZnVuY3Rpb24oKSB7IGlmICh0WzBdICYgMSkgdGhyb3cgdFsxXTsgcmV0dXJuIHRbMV07IH0sIHRyeXM6IFtdLCBvcHM6IFtdIH0sIGYsIHksIHQsIGc7XHJcbiAgICByZXR1cm4gZyA9IHsgbmV4dDogdmVyYigwKSwgXCJ0aHJvd1wiOiB2ZXJiKDEpLCBcInJldHVyblwiOiB2ZXJiKDIpIH0sIHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiAoZ1tTeW1ib2wuaXRlcmF0b3JdID0gZnVuY3Rpb24oKSB7IHJldHVybiB0aGlzOyB9KSwgZztcclxuICAgIGZ1bmN0aW9uIHZlcmIobikgeyByZXR1cm4gZnVuY3Rpb24gKHYpIHsgcmV0dXJuIHN0ZXAoW24sIHZdKTsgfTsgfVxyXG4gICAgZnVuY3Rpb24gc3RlcChvcCkge1xyXG4gICAgICAgIGlmIChmKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiR2VuZXJhdG9yIGlzIGFscmVhZHkgZXhlY3V0aW5nLlwiKTtcclxuICAgICAgICB3aGlsZSAoXykgdHJ5IHtcclxuICAgICAgICAgICAgaWYgKGYgPSAxLCB5ICYmICh0ID0gb3BbMF0gJiAyID8geVtcInJldHVyblwiXSA6IG9wWzBdID8geVtcInRocm93XCJdIHx8ICgodCA9IHlbXCJyZXR1cm5cIl0pICYmIHQuY2FsbCh5KSwgMCkgOiB5Lm5leHQpICYmICEodCA9IHQuY2FsbCh5LCBvcFsxXSkpLmRvbmUpIHJldHVybiB0O1xyXG4gICAgICAgICAgICBpZiAoeSA9IDAsIHQpIG9wID0gW29wWzBdICYgMiwgdC52YWx1ZV07XHJcbiAgICAgICAgICAgIHN3aXRjaCAob3BbMF0pIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDogY2FzZSAxOiB0ID0gb3A7IGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA0OiBfLmxhYmVsKys7IHJldHVybiB7IHZhbHVlOiBvcFsxXSwgZG9uZTogZmFsc2UgfTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNTogXy5sYWJlbCsrOyB5ID0gb3BbMV07IG9wID0gWzBdOyBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNzogb3AgPSBfLm9wcy5wb3AoKTsgXy50cnlzLnBvcCgpOyBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCEodCA9IF8udHJ5cywgdCA9IHQubGVuZ3RoID4gMCAmJiB0W3QubGVuZ3RoIC0gMV0pICYmIChvcFswXSA9PT0gNiB8fCBvcFswXSA9PT0gMikpIHsgXyA9IDA7IGNvbnRpbnVlOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKG9wWzBdID09PSAzICYmICghdCB8fCAob3BbMV0gPiB0WzBdICYmIG9wWzFdIDwgdFszXSkpKSB7IF8ubGFiZWwgPSBvcFsxXTsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAob3BbMF0gPT09IDYgJiYgXy5sYWJlbCA8IHRbMV0pIHsgXy5sYWJlbCA9IHRbMV07IHQgPSBvcDsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAodCAmJiBfLmxhYmVsIDwgdFsyXSkgeyBfLmxhYmVsID0gdFsyXTsgXy5vcHMucHVzaChvcCk7IGJyZWFrOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRbMl0pIF8ub3BzLnBvcCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIF8udHJ5cy5wb3AoKTsgY29udGludWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgb3AgPSBib2R5LmNhbGwodGhpc0FyZywgXyk7XHJcbiAgICAgICAgfSBjYXRjaCAoZSkgeyBvcCA9IFs2LCBlXTsgeSA9IDA7IH0gZmluYWxseSB7IGYgPSB0ID0gMDsgfVxyXG4gICAgICAgIGlmIChvcFswXSAmIDUpIHRocm93IG9wWzFdOyByZXR1cm4geyB2YWx1ZTogb3BbMF0gPyBvcFsxXSA6IHZvaWQgMCwgZG9uZTogdHJ1ZSB9O1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19leHBvcnRTdGFyKG0sIGV4cG9ydHMpIHtcclxuICAgIGZvciAodmFyIHAgaW4gbSkgaWYgKCFleHBvcnRzLmhhc093blByb3BlcnR5KHApKSBleHBvcnRzW3BdID0gbVtwXTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fdmFsdWVzKG8pIHtcclxuICAgIHZhciBtID0gdHlwZW9mIFN5bWJvbCA9PT0gXCJmdW5jdGlvblwiICYmIG9bU3ltYm9sLml0ZXJhdG9yXSwgaSA9IDA7XHJcbiAgICBpZiAobSkgcmV0dXJuIG0uY2FsbChvKTtcclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgbmV4dDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBpZiAobyAmJiBpID49IG8ubGVuZ3RoKSBvID0gdm9pZCAwO1xyXG4gICAgICAgICAgICByZXR1cm4geyB2YWx1ZTogbyAmJiBvW2krK10sIGRvbmU6ICFvIH07XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fcmVhZChvLCBuKSB7XHJcbiAgICB2YXIgbSA9IHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiBvW1N5bWJvbC5pdGVyYXRvcl07XHJcbiAgICBpZiAoIW0pIHJldHVybiBvO1xyXG4gICAgdmFyIGkgPSBtLmNhbGwobyksIHIsIGFyID0gW10sIGU7XHJcbiAgICB0cnkge1xyXG4gICAgICAgIHdoaWxlICgobiA9PT0gdm9pZCAwIHx8IG4tLSA+IDApICYmICEociA9IGkubmV4dCgpKS5kb25lKSBhci5wdXNoKHIudmFsdWUpO1xyXG4gICAgfVxyXG4gICAgY2F0Y2ggKGVycm9yKSB7IGUgPSB7IGVycm9yOiBlcnJvciB9OyB9XHJcbiAgICBmaW5hbGx5IHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBpZiAociAmJiAhci5kb25lICYmIChtID0gaVtcInJldHVyblwiXSkpIG0uY2FsbChpKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZmluYWxseSB7IGlmIChlKSB0aHJvdyBlLmVycm9yOyB9XHJcbiAgICB9XHJcbiAgICByZXR1cm4gYXI7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX3NwcmVhZCgpIHtcclxuICAgIGZvciAodmFyIGFyID0gW10sIGkgPSAwOyBpIDwgYXJndW1lbnRzLmxlbmd0aDsgaSsrKVxyXG4gICAgICAgIGFyID0gYXIuY29uY2F0KF9fcmVhZChhcmd1bWVudHNbaV0pKTtcclxuICAgIHJldHVybiBhcjtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fYXdhaXQodikge1xyXG4gICAgcmV0dXJuIHRoaXMgaW5zdGFuY2VvZiBfX2F3YWl0ID8gKHRoaXMudiA9IHYsIHRoaXMpIDogbmV3IF9fYXdhaXQodik7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX2FzeW5jR2VuZXJhdG9yKHRoaXNBcmcsIF9hcmd1bWVudHMsIGdlbmVyYXRvcikge1xyXG4gICAgaWYgKCFTeW1ib2wuYXN5bmNJdGVyYXRvcikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIlN5bWJvbC5hc3luY0l0ZXJhdG9yIGlzIG5vdCBkZWZpbmVkLlwiKTtcclxuICAgIHZhciBnID0gZ2VuZXJhdG9yLmFwcGx5KHRoaXNBcmcsIF9hcmd1bWVudHMgfHwgW10pLCBpLCBxID0gW107XHJcbiAgICByZXR1cm4gaSA9IHt9LCB2ZXJiKFwibmV4dFwiKSwgdmVyYihcInRocm93XCIpLCB2ZXJiKFwicmV0dXJuXCIpLCBpW1N5bWJvbC5hc3luY0l0ZXJhdG9yXSA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRoaXM7IH0sIGk7XHJcbiAgICBmdW5jdGlvbiB2ZXJiKG4pIHsgaWYgKGdbbl0pIGlbbl0gPSBmdW5jdGlvbiAodikgeyByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKGEsIGIpIHsgcS5wdXNoKFtuLCB2LCBhLCBiXSkgPiAxIHx8IHJlc3VtZShuLCB2KTsgfSk7IH07IH1cclxuICAgIGZ1bmN0aW9uIHJlc3VtZShuLCB2KSB7IHRyeSB7IHN0ZXAoZ1tuXSh2KSk7IH0gY2F0Y2ggKGUpIHsgc2V0dGxlKHFbMF1bM10sIGUpOyB9IH1cclxuICAgIGZ1bmN0aW9uIHN0ZXAocikgeyByLnZhbHVlIGluc3RhbmNlb2YgX19hd2FpdCA/IFByb21pc2UucmVzb2x2ZShyLnZhbHVlLnYpLnRoZW4oZnVsZmlsbCwgcmVqZWN0KSA6IHNldHRsZShxWzBdWzJdLCByKTsgfVxyXG4gICAgZnVuY3Rpb24gZnVsZmlsbCh2YWx1ZSkgeyByZXN1bWUoXCJuZXh0XCIsIHZhbHVlKTsgfVxyXG4gICAgZnVuY3Rpb24gcmVqZWN0KHZhbHVlKSB7IHJlc3VtZShcInRocm93XCIsIHZhbHVlKTsgfVxyXG4gICAgZnVuY3Rpb24gc2V0dGxlKGYsIHYpIHsgaWYgKGYodiksIHEuc2hpZnQoKSwgcS5sZW5ndGgpIHJlc3VtZShxWzBdWzBdLCBxWzBdWzFdKTsgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19hc3luY0RlbGVnYXRvcihvKSB7XHJcbiAgICB2YXIgaSwgcDtcclxuICAgIHJldHVybiBpID0ge30sIHZlcmIoXCJuZXh0XCIpLCB2ZXJiKFwidGhyb3dcIiwgZnVuY3Rpb24gKGUpIHsgdGhyb3cgZTsgfSksIHZlcmIoXCJyZXR1cm5cIiksIGlbU3ltYm9sLml0ZXJhdG9yXSA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRoaXM7IH0sIGk7XHJcbiAgICBmdW5jdGlvbiB2ZXJiKG4sIGYpIHsgaVtuXSA9IG9bbl0gPyBmdW5jdGlvbiAodikgeyByZXR1cm4gKHAgPSAhcCkgPyB7IHZhbHVlOiBfX2F3YWl0KG9bbl0odikpLCBkb25lOiBuID09PSBcInJldHVyblwiIH0gOiBmID8gZih2KSA6IHY7IH0gOiBmOyB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX2FzeW5jVmFsdWVzKG8pIHtcclxuICAgIGlmICghU3ltYm9sLmFzeW5jSXRlcmF0b3IpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJTeW1ib2wuYXN5bmNJdGVyYXRvciBpcyBub3QgZGVmaW5lZC5cIik7XHJcbiAgICB2YXIgbSA9IG9bU3ltYm9sLmFzeW5jSXRlcmF0b3JdLCBpO1xyXG4gICAgcmV0dXJuIG0gPyBtLmNhbGwobykgOiAobyA9IHR5cGVvZiBfX3ZhbHVlcyA9PT0gXCJmdW5jdGlvblwiID8gX192YWx1ZXMobykgOiBvW1N5bWJvbC5pdGVyYXRvcl0oKSwgaSA9IHt9LCB2ZXJiKFwibmV4dFwiKSwgdmVyYihcInRocm93XCIpLCB2ZXJiKFwicmV0dXJuXCIpLCBpW1N5bWJvbC5hc3luY0l0ZXJhdG9yXSA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRoaXM7IH0sIGkpO1xyXG4gICAgZnVuY3Rpb24gdmVyYihuKSB7IGlbbl0gPSBvW25dICYmIGZ1bmN0aW9uICh2KSB7IHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7IHYgPSBvW25dKHYpLCBzZXR0bGUocmVzb2x2ZSwgcmVqZWN0LCB2LmRvbmUsIHYudmFsdWUpOyB9KTsgfTsgfVxyXG4gICAgZnVuY3Rpb24gc2V0dGxlKHJlc29sdmUsIHJlamVjdCwgZCwgdikgeyBQcm9taXNlLnJlc29sdmUodikudGhlbihmdW5jdGlvbih2KSB7IHJlc29sdmUoeyB2YWx1ZTogdiwgZG9uZTogZCB9KTsgfSwgcmVqZWN0KTsgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19tYWtlVGVtcGxhdGVPYmplY3QoY29va2VkLCByYXcpIHtcclxuICAgIGlmIChPYmplY3QuZGVmaW5lUHJvcGVydHkpIHsgT2JqZWN0LmRlZmluZVByb3BlcnR5KGNvb2tlZCwgXCJyYXdcIiwgeyB2YWx1ZTogcmF3IH0pOyB9IGVsc2UgeyBjb29rZWQucmF3ID0gcmF3OyB9XHJcbiAgICByZXR1cm4gY29va2VkO1xyXG59O1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9faW1wb3J0U3Rhcihtb2QpIHtcclxuICAgIGlmIChtb2QgJiYgbW9kLl9fZXNNb2R1bGUpIHJldHVybiBtb2Q7XHJcbiAgICB2YXIgcmVzdWx0ID0ge307XHJcbiAgICBpZiAobW9kICE9IG51bGwpIGZvciAodmFyIGsgaW4gbW9kKSBpZiAoT2JqZWN0Lmhhc093blByb3BlcnR5LmNhbGwobW9kLCBrKSkgcmVzdWx0W2tdID0gbW9kW2tdO1xyXG4gICAgcmVzdWx0LmRlZmF1bHQgPSBtb2Q7XHJcbiAgICByZXR1cm4gcmVzdWx0O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19pbXBvcnREZWZhdWx0KG1vZCkge1xyXG4gICAgcmV0dXJuIChtb2QgJiYgbW9kLl9fZXNNb2R1bGUpID8gbW9kIDogeyBkZWZhdWx0OiBtb2QgfTtcclxufVxyXG4iLCJleHBvcnQgY29uc3QgRGF5cyA9IHtcclxuICAgICdTVU4nOiAnU3VuZGF5JyxcclxuICAgICdNT04nOiAnTW9uZGF5JyxcclxuICAgICdUVUUnOiAnVHVlc2RheScsXHJcbiAgICAnV0VEJzogJ1dlZG5lc2RheScsXHJcbiAgICAnVEhVJzogJ1RodXJzZGF5JyxcclxuICAgICdGUkknOiAnRnJpZGF5JyxcclxuICAgICdTQVQnOiAnU2F0dXJkYXknXHJcbn07XHJcblxyXG5leHBvcnQgY29uc3QgTW9udGhXZWVrcyA9IHtcclxuICAgICcjMSc6ICdGaXJzdCcsXHJcbiAgICAnIzInOiAnU2Vjb25kJyxcclxuICAgICcjMyc6ICdUaGlyZCcsXHJcbiAgICAnIzQnOiAnRm91cnRoJyxcclxuICAgICcjNSc6ICdGaWZ0aCcsXHJcbiAgICAnTCc6ICdMYXN0J1xyXG59O1xyXG5cclxuZXhwb3J0IGVudW0gTW9udGhzIHtcclxuICAgIEphbnVhcnkgPSAxLFxyXG4gICAgRmVicnVhcnksXHJcbiAgICBNYXJjaCxcclxuICAgIEFwcmlsLFxyXG4gICAgTWF5LFxyXG4gICAgSnVuZSxcclxuICAgIEp1bHksXHJcbiAgICBBdWd1c3QsXHJcbiAgICBTZXB0ZW1iZXIsXHJcbiAgICBPY3RvYmVyLFxyXG4gICAgTm92ZW1iZXIsXHJcbiAgICBEZWNlbWJlclxyXG59XHJcbiIsIi8vIEBkeW5hbWljXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFV0aWxzIHtcclxuICAgIC8qKiBUaGlzIHJldHVybnMgYSByYW5nZSBvZiBudW1iZXJzLiBTdGFydHMgZnJvbSAwIGlmICdzdGFydEZyb20nIGlzIG5vdCBzZXQgKi9cclxuICAgIHB1YmxpYyBzdGF0aWMgZ2V0UmFuZ2Uoc3RhcnRGcm9tOiBudW1iZXIsIHVudGlsOiBudW1iZXIpIHtcclxuICAgICAgICByZXR1cm4gQXJyYXkuZnJvbSh7IGxlbmd0aDogKHVudGlsICsgMSAtIHN0YXJ0RnJvbSkgfSwgKF8sIGspID0+IGsgKyBzdGFydEZyb20pO1xyXG4gICAgfVxyXG59XHJcbiIsImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0LCBJbnB1dCwgT3V0cHV0LCBFdmVudEVtaXR0ZXIsIFNpbXBsZUNoYW5nZXMsIE9uQ2hhbmdlcyB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBDcm9uT3B0aW9ucyB9IGZyb20gJy4vQ3Jvbk9wdGlvbnMnO1xyXG5cclxuaW1wb3J0IHsgRGF5cywgTW9udGhXZWVrcywgTW9udGhzIH0gZnJvbSAnLi9lbnVtcyc7XHJcbmltcG9ydCBVdGlscyBmcm9tICcuL1V0aWxzJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiAnY3Jvbi1lZGl0b3InLFxyXG4gIHRlbXBsYXRlVXJsOiAnLi9jcm9uLWVkaXRvci5jb21wb25lbnQuaHRtbCcsXHJcbiAgc3R5bGVVcmxzOiBbJy4vY3Jvbi1lZGl0b3IuY29tcG9uZW50LmNzcyddXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBDcm9uRWRpdG9yQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0LCBPbkNoYW5nZXMge1xyXG4gIEBJbnB1dCgpIHB1YmxpYyBkaXNhYmxlZDogYm9vbGVhbjtcclxuICBASW5wdXQoKSBwdWJsaWMgb3B0aW9uczogQ3Jvbk9wdGlvbnM7XHJcblxyXG4gIEBJbnB1dCgpIGdldCBjcm9uKCk6IHN0cmluZyB7IHJldHVybiB0aGlzLmxvY2FsQ3JvbjsgfVxyXG4gIHNldCBjcm9uKHZhbHVlOiBzdHJpbmcpIHtcclxuICAgIHRoaXMubG9jYWxDcm9uID0gdmFsdWU7XHJcbiAgICB0aGlzLmNyb25DaGFuZ2UuZW1pdCh0aGlzLmxvY2FsQ3Jvbik7XHJcbiAgfVxyXG5cclxuICAvLyB0aGUgbmFtZSBpcyBhbiBBbmd1bGFyIGNvbnZlbnRpb24sIEBJbnB1dCB2YXJpYWJsZSBuYW1lICsgXCJDaGFuZ2VcIiBzdWZmaXhcclxuICBAT3V0cHV0KCkgY3JvbkNoYW5nZSA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuXHJcbiAgcHVibGljIGFjdGl2ZVRhYjogc3RyaW5nO1xyXG4gIHB1YmxpYyBzZWxlY3RPcHRpb25zID0gdGhpcy5nZXRTZWxlY3RPcHRpb25zKCk7XHJcbiAgcHVibGljIHN0YXRlOiBhbnk7XHJcblxyXG4gIHByaXZhdGUgbG9jYWxDcm9uOiBzdHJpbmc7XHJcbiAgcHJpdmF0ZSBpc0RpcnR5OiBib29sZWFuO1xyXG5cclxuICBwdWJsaWMgbmdPbkluaXQoKSB7XHJcbiAgICBpZiAodGhpcy5vcHRpb25zLnJlbW92ZVNlY29uZHMpIHtcclxuICAgICAgdGhpcy5vcHRpb25zLmhpZGVTZWNvbmRzID0gdHJ1ZTtcclxuICAgIH1cclxuXHJcbiAgICB0aGlzLnN0YXRlID0gdGhpcy5nZXREZWZhdWx0U3RhdGUoKTtcclxuXHJcbiAgICB0aGlzLmhhbmRsZU1vZGVsQ2hhbmdlKHRoaXMuY3Jvbik7XHJcbiAgfVxyXG5cclxuICBwdWJsaWMgbmdPbkNoYW5nZXMoY2hhbmdlczogU2ltcGxlQ2hhbmdlcykge1xyXG4gICAgY29uc3QgbmV3Q3JvbiA9IGNoYW5nZXNbJ2Nyb24nXTtcclxuICAgIGlmIChuZXdDcm9uICYmICFuZXdDcm9uLmZpcnN0Q2hhbmdlKSB7XHJcbiAgICAgIHRoaXMuaGFuZGxlTW9kZWxDaGFuZ2UodGhpcy5jcm9uKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHB1YmxpYyBzZXRBY3RpdmVUYWIodGFiOiBzdHJpbmcpIHtcclxuICAgIGlmICghdGhpcy5kaXNhYmxlZCkge1xyXG4gICAgICB0aGlzLmFjdGl2ZVRhYiA9IHRhYjtcclxuICAgICAgdGhpcy5yZWdlbmVyYXRlQ3JvbigpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcHVibGljIGRheURpc3BsYXkoZGF5OiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgcmV0dXJuIERheXNbZGF5XTtcclxuICB9XHJcblxyXG4gIHB1YmxpYyBtb250aFdlZWtEaXNwbGF5KG1vbnRoV2Vla051bWJlcjogbnVtYmVyKTogc3RyaW5nIHtcclxuICAgIHJldHVybiBNb250aFdlZWtzW21vbnRoV2Vla051bWJlcl07XHJcbiAgfVxyXG5cclxuICBwdWJsaWMgbW9udGhEaXNwbGF5KG1vbnRoOiBudW1iZXIpOiBzdHJpbmcge1xyXG4gICAgcmV0dXJuIE1vbnRoc1ttb250aF07XHJcbiAgfVxyXG5cclxuICBwdWJsaWMgbW9udGhEYXlEaXNwbGF5KG1vbnRoOiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgaWYgKG1vbnRoID09PSAnTCcpIHtcclxuICAgICAgcmV0dXJuICdMYXN0IERheSc7XHJcbiAgICB9IGVsc2UgaWYgKG1vbnRoID09PSAnTFcnKSB7XHJcbiAgICAgIHJldHVybiAnTGFzdCBXZWVrZGF5JztcclxuICAgIH0gZWxzZSBpZiAobW9udGggPT09ICcxVycpIHtcclxuICAgICAgcmV0dXJuICdGaXJzdCBXZWVrZGF5JztcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiBgJHttb250aH0ke3RoaXMuZ2V0T3JkaW5hbFN1ZmZpeChtb250aCl9IGRheWA7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBwdWJsaWMgcmVnZW5lcmF0ZUNyb24oKSB7XHJcbiAgICB0aGlzLmlzRGlydHkgPSB0cnVlO1xyXG5cclxuICAgIHN3aXRjaCAodGhpcy5hY3RpdmVUYWIpIHtcclxuICAgICAgY2FzZSAnbWludXRlcyc6XHJcbiAgICAgICAgdGhpcy5jcm9uID0gYDAvJHt0aGlzLnN0YXRlLm1pbnV0ZXMubWludXRlc30gKiAxLzEgKiA/YDtcclxuXHJcbiAgICAgICAgaWYgKCF0aGlzLm9wdGlvbnMucmVtb3ZlU2Vjb25kcykge1xyXG4gICAgICAgICAgdGhpcy5jcm9uID0gYCR7dGhpcy5zdGF0ZS5taW51dGVzLnNlY29uZHN9ICR7dGhpcy5jcm9ufWA7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoIXRoaXMub3B0aW9ucy5yZW1vdmVZZWFycykge1xyXG4gICAgICAgICAgdGhpcy5jcm9uID0gYCR7dGhpcy5jcm9ufSAqYDtcclxuICAgICAgICB9XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGNhc2UgJ2hvdXJseSc6XHJcbiAgICAgICAgdGhpcy5jcm9uID0gYCR7dGhpcy5zdGF0ZS5ob3VybHkubWludXRlc30gMC8ke3RoaXMuc3RhdGUuaG91cmx5LmhvdXJzfSAxLzEgKiA/YDtcclxuXHJcbiAgICAgICAgaWYgKCF0aGlzLm9wdGlvbnMucmVtb3ZlU2Vjb25kcykge1xyXG4gICAgICAgICAgdGhpcy5jcm9uID0gYCR7dGhpcy5zdGF0ZS5ob3VybHkuc2Vjb25kc30gJHt0aGlzLmNyb259YDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICghdGhpcy5vcHRpb25zLnJlbW92ZVllYXJzKSB7XHJcbiAgICAgICAgICB0aGlzLmNyb24gPSBgJHt0aGlzLmNyb259ICpgO1xyXG4gICAgICAgIH1cclxuICAgICAgICBicmVhaztcclxuICAgICAgY2FzZSAnZGFpbHknOlxyXG4gICAgICAgIHN3aXRjaCAodGhpcy5zdGF0ZS5kYWlseS5zdWJUYWIpIHtcclxuICAgICAgICAgIGNhc2UgJ2V2ZXJ5RGF5cyc6XHJcbiAgICAgICAgICAgIC8vIHRzbGludDpkaXNhYmxlLW5leHQtbGluZTptYXgtbGluZS1sZW5ndGhcclxuICAgICAgICAgICAgdGhpcy5jcm9uID0gYCR7dGhpcy5zdGF0ZS5kYWlseS5ldmVyeURheXMubWludXRlc30gJHt0aGlzLmhvdXJUb0Nyb24odGhpcy5zdGF0ZS5kYWlseS5ldmVyeURheXMuaG91cnMsIHRoaXMuc3RhdGUuZGFpbHkuZXZlcnlEYXlzLmhvdXJUeXBlKX0gMS8ke3RoaXMuc3RhdGUuZGFpbHkuZXZlcnlEYXlzLmRheXN9ICogP2A7XHJcblxyXG4gICAgICAgICAgICBpZiAoIXRoaXMub3B0aW9ucy5yZW1vdmVTZWNvbmRzKSB7XHJcbiAgICAgICAgICAgICAgdGhpcy5jcm9uID0gYCR7dGhpcy5zdGF0ZS5kYWlseS5ldmVyeURheXMuc2Vjb25kc30gJHt0aGlzLmNyb259YDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaWYgKCF0aGlzLm9wdGlvbnMucmVtb3ZlWWVhcnMpIHtcclxuICAgICAgICAgICAgICB0aGlzLmNyb24gPSBgJHt0aGlzLmNyb259ICpgO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgY2FzZSAnZXZlcnlXZWVrRGF5JzpcclxuICAgICAgICAgICAgLy8gdHNsaW50OmRpc2FibGUtbmV4dC1saW5lOm1heC1saW5lLWxlbmd0aFxyXG4gICAgICAgICAgICB0aGlzLmNyb24gPSBgJHt0aGlzLnN0YXRlLmRhaWx5LmV2ZXJ5V2Vla0RheS5taW51dGVzfSAke3RoaXMuaG91clRvQ3Jvbih0aGlzLnN0YXRlLmRhaWx5LmV2ZXJ5V2Vla0RheS5ob3VycywgdGhpcy5zdGF0ZS5kYWlseS5ldmVyeVdlZWtEYXkuaG91clR5cGUpfSA/ICogTU9OLUZSSWA7XHJcblxyXG4gICAgICAgICAgICBpZiAoIXRoaXMub3B0aW9ucy5yZW1vdmVTZWNvbmRzKSB7XHJcbiAgICAgICAgICAgICAgdGhpcy5jcm9uID0gYCR7dGhpcy5zdGF0ZS5kYWlseS5ldmVyeVdlZWtEYXkuc2Vjb25kc30gJHt0aGlzLmNyb259YDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaWYgKCF0aGlzLm9wdGlvbnMucmVtb3ZlWWVhcnMpIHtcclxuICAgICAgICAgICAgICB0aGlzLmNyb24gPSBgJHt0aGlzLmNyb259ICpgO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdJbnZhbGlkIGNyb24gZGFpbHkgc3VidGFiIHNlbGVjdGlvbicpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBicmVhaztcclxuICAgICAgY2FzZSAnd2Vla2x5JzpcclxuICAgICAgICBjb25zdCBkYXlzID0gdGhpcy5zZWxlY3RPcHRpb25zLmRheXNcclxuICAgICAgICAgIC5yZWR1Y2UoKGFjYywgZGF5KSA9PiB0aGlzLnN0YXRlLndlZWtseVtkYXldID8gYWNjLmNvbmNhdChbZGF5XSkgOiBhY2MsIFtdKVxyXG4gICAgICAgICAgLmpvaW4oJywnKTtcclxuICAgICAgICB0aGlzLmNyb24gPSBgJHt0aGlzLnN0YXRlLndlZWtseS5taW51dGVzfSAke3RoaXMuaG91clRvQ3Jvbih0aGlzLnN0YXRlLndlZWtseS5ob3VycywgdGhpcy5zdGF0ZS53ZWVrbHkuaG91clR5cGUpfSA/ICogJHtkYXlzfWA7XHJcblxyXG4gICAgICAgIGlmICghdGhpcy5vcHRpb25zLnJlbW92ZVNlY29uZHMpIHtcclxuICAgICAgICAgIHRoaXMuY3JvbiA9IGAke3RoaXMuc3RhdGUud2Vla2x5LnNlY29uZHN9ICR7dGhpcy5jcm9ufWA7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoIXRoaXMub3B0aW9ucy5yZW1vdmVZZWFycykge1xyXG4gICAgICAgICAgdGhpcy5jcm9uID0gYCR7dGhpcy5jcm9ufSAqYDtcclxuICAgICAgICB9XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGNhc2UgJ21vbnRobHknOlxyXG4gICAgICAgIHN3aXRjaCAodGhpcy5zdGF0ZS5tb250aGx5LnN1YlRhYikge1xyXG4gICAgICAgICAgY2FzZSAnc3BlY2lmaWNEYXknOlxyXG4gICAgICAgICAgICBjb25zdCBkYXkgPSB0aGlzLnN0YXRlLm1vbnRobHkucnVuT25XZWVrZGF5ID8gYCR7dGhpcy5zdGF0ZS5tb250aGx5LnNwZWNpZmljRGF5LmRheX1XYCA6IHRoaXMuc3RhdGUubW9udGhseS5zcGVjaWZpY0RheS5kYXk7XHJcbiAgICAgICAgICAgIC8vIHRzbGludDpkaXNhYmxlLW5leHQtbGluZTptYXgtbGluZS1sZW5ndGhcclxuICAgICAgICAgICAgdGhpcy5jcm9uID0gYCR7dGhpcy5zdGF0ZS5tb250aGx5LnNwZWNpZmljRGF5Lm1pbnV0ZXN9ICR7dGhpcy5ob3VyVG9Dcm9uKHRoaXMuc3RhdGUubW9udGhseS5zcGVjaWZpY0RheS5ob3VycywgdGhpcy5zdGF0ZS5tb250aGx5LnNwZWNpZmljRGF5LmhvdXJUeXBlKX0gJHtkYXl9IDEvJHt0aGlzLnN0YXRlLm1vbnRobHkuc3BlY2lmaWNEYXkubW9udGhzfSA/YDtcclxuXHJcbiAgICAgICAgICAgIGlmICghdGhpcy5vcHRpb25zLnJlbW92ZVNlY29uZHMpIHtcclxuICAgICAgICAgICAgICB0aGlzLmNyb24gPSBgJHt0aGlzLnN0YXRlLm1vbnRobHkuc3BlY2lmaWNEYXkuc2Vjb25kc30gJHt0aGlzLmNyb259YDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaWYgKCF0aGlzLm9wdGlvbnMucmVtb3ZlWWVhcnMpIHtcclxuICAgICAgICAgICAgICB0aGlzLmNyb24gPSBgJHt0aGlzLmNyb259ICpgO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgY2FzZSAnc3BlY2lmaWNXZWVrRGF5JzpcclxuICAgICAgICAgICAgLy8gdHNsaW50OmRpc2FibGUtbmV4dC1saW5lOm1heC1saW5lLWxlbmd0aFxyXG4gICAgICAgICAgICB0aGlzLmNyb24gPSBgJHt0aGlzLnN0YXRlLm1vbnRobHkuc3BlY2lmaWNXZWVrRGF5Lm1pbnV0ZXN9ICR7dGhpcy5ob3VyVG9Dcm9uKHRoaXMuc3RhdGUubW9udGhseS5zcGVjaWZpY1dlZWtEYXkuaG91cnMsIHRoaXMuc3RhdGUubW9udGhseS5zcGVjaWZpY1dlZWtEYXkuaG91clR5cGUpfSA/ICR7dGhpcy5zdGF0ZS5tb250aGx5LnNwZWNpZmljV2Vla0RheS5zdGFydE1vbnRofS8ke3RoaXMuc3RhdGUubW9udGhseS5zcGVjaWZpY1dlZWtEYXkubW9udGhzfSAke3RoaXMuc3RhdGUubW9udGhseS5zcGVjaWZpY1dlZWtEYXkuZGF5fSR7dGhpcy5zdGF0ZS5tb250aGx5LnNwZWNpZmljV2Vla0RheS5tb250aFdlZWt9YDtcclxuXHJcbiAgICAgICAgICAgIGlmICghdGhpcy5vcHRpb25zLnJlbW92ZVNlY29uZHMpIHtcclxuICAgICAgICAgICAgICB0aGlzLmNyb24gPSBgJHt0aGlzLnN0YXRlLm1vbnRobHkuc3BlY2lmaWNXZWVrRGF5LnNlY29uZHN9ICR7dGhpcy5jcm9ufWA7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlmICghdGhpcy5vcHRpb25zLnJlbW92ZVllYXJzKSB7XHJcbiAgICAgICAgICAgICAgdGhpcy5jcm9uID0gYCR7dGhpcy5jcm9ufSAqYDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignSW52YWxpZCBjcm9uIG1vbnRobHkgc3VidGFiIHNlbGVjdGlvbicpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBicmVhaztcclxuICAgICAgY2FzZSAneWVhcmx5JzpcclxuICAgICAgICBzd2l0Y2ggKHRoaXMuc3RhdGUueWVhcmx5LnN1YlRhYikge1xyXG4gICAgICAgICAgY2FzZSAnc3BlY2lmaWNNb250aERheSc6XHJcbiAgICAgICAgICAgIC8vIHRzbGludDpkaXNhYmxlLW5leHQtbGluZTptYXgtbGluZS1sZW5ndGhcclxuICAgICAgICAgICAgY29uc3QgZGF5ID0gdGhpcy5zdGF0ZS55ZWFybHkucnVuT25XZWVrZGF5ID8gYCR7dGhpcy5zdGF0ZS55ZWFybHkuc3BlY2lmaWNNb250aERheS5kYXl9V2AgOiB0aGlzLnN0YXRlLnllYXJseS5zcGVjaWZpY01vbnRoRGF5LmRheTtcclxuICAgICAgICAgICAgLy8gdHNsaW50OmRpc2FibGUtbmV4dC1saW5lOm1heC1saW5lLWxlbmd0aFxyXG4gICAgICAgICAgICB0aGlzLmNyb24gPSBgJHt0aGlzLnN0YXRlLnllYXJseS5zcGVjaWZpY01vbnRoRGF5Lm1pbnV0ZXN9ICR7dGhpcy5ob3VyVG9Dcm9uKHRoaXMuc3RhdGUueWVhcmx5LnNwZWNpZmljTW9udGhEYXkuaG91cnMsIHRoaXMuc3RhdGUueWVhcmx5LnNwZWNpZmljTW9udGhEYXkuaG91clR5cGUpfSAke2RheX0gJHt0aGlzLnN0YXRlLnllYXJseS5zcGVjaWZpY01vbnRoRGF5Lm1vbnRofSA/YDtcclxuXHJcbiAgICAgICAgICAgIGlmICghdGhpcy5vcHRpb25zLnJlbW92ZVNlY29uZHMpIHtcclxuICAgICAgICAgICAgICB0aGlzLmNyb24gPSBgJHt0aGlzLnN0YXRlLnllYXJseS5zcGVjaWZpY01vbnRoRGF5LnNlY29uZHN9ICR7dGhpcy5jcm9ufWA7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlmICghdGhpcy5vcHRpb25zLnJlbW92ZVllYXJzKSB7XHJcbiAgICAgICAgICAgICAgdGhpcy5jcm9uID0gYCR7dGhpcy5jcm9ufSAqYDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgIGNhc2UgJ3NwZWNpZmljTW9udGhXZWVrJzpcclxuICAgICAgICAgICAgLy8gdHNsaW50OmRpc2FibGUtbmV4dC1saW5lOm1heC1saW5lLWxlbmd0aFxyXG4gICAgICAgICAgICB0aGlzLmNyb24gPSBgJHt0aGlzLnN0YXRlLnllYXJseS5zcGVjaWZpY01vbnRoV2Vlay5taW51dGVzfSAke3RoaXMuaG91clRvQ3Jvbih0aGlzLnN0YXRlLnllYXJseS5zcGVjaWZpY01vbnRoV2Vlay5ob3VycywgdGhpcy5zdGF0ZS55ZWFybHkuc3BlY2lmaWNNb250aFdlZWsuaG91clR5cGUpfSA/ICR7dGhpcy5zdGF0ZS55ZWFybHkuc3BlY2lmaWNNb250aFdlZWsubW9udGh9ICR7dGhpcy5zdGF0ZS55ZWFybHkuc3BlY2lmaWNNb250aFdlZWsuZGF5fSR7dGhpcy5zdGF0ZS55ZWFybHkuc3BlY2lmaWNNb250aFdlZWsubW9udGhXZWVrfWA7XHJcblxyXG4gICAgICAgICAgICBpZiAoIXRoaXMub3B0aW9ucy5yZW1vdmVTZWNvbmRzKSB7XHJcbiAgICAgICAgICAgICAgdGhpcy5jcm9uID0gYCR7dGhpcy5zdGF0ZS55ZWFybHkuc3BlY2lmaWNNb250aFdlZWsuc2Vjb25kc30gJHt0aGlzLmNyb259YDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaWYgKCF0aGlzLm9wdGlvbnMucmVtb3ZlWWVhcnMpIHtcclxuICAgICAgICAgICAgICB0aGlzLmNyb24gPSBgJHt0aGlzLmNyb259ICpgO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdJbnZhbGlkIGNyb24geWVhcmx5IHN1YnRhYiBzZWxlY3Rpb24nKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGNhc2UgJ2FkdmFuY2VkJzpcclxuICAgICAgICB0aGlzLmNyb24gPSB0aGlzLnN0YXRlLmFkdmFuY2VkLmV4cHJlc3Npb247XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdJbnZhbGlkIGNyb24gYWN0aXZlIHRhYiBzZWxlY3Rpb24nKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHByaXZhdGUgZ2V0QW1QbUhvdXIoaG91cjogbnVtYmVyKSB7XHJcbiAgICByZXR1cm4gdGhpcy5vcHRpb25zLnVzZTI0SG91clRpbWUgPyBob3VyIDogKGhvdXIgKyAxMSkgJSAxMiArIDE7XHJcbiAgfVxyXG5cclxuICBwcml2YXRlIGdldEhvdXJUeXBlKGhvdXI6IG51bWJlcikge1xyXG4gICAgcmV0dXJuIHRoaXMub3B0aW9ucy51c2UyNEhvdXJUaW1lID8gdW5kZWZpbmVkIDogKGhvdXIgPj0gMTIgPyAnUE0nIDogJ0FNJyk7XHJcbiAgfVxyXG5cclxuICBwcml2YXRlIGhvdXJUb0Nyb24oaG91cjogbnVtYmVyLCBob3VyVHlwZTogc3RyaW5nKSB7XHJcbiAgICBpZiAodGhpcy5vcHRpb25zLnVzZTI0SG91clRpbWUpIHtcclxuICAgICAgcmV0dXJuIGhvdXI7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4gaG91clR5cGUgPT09ICdBTScgPyAoaG91ciA9PT0gMTIgPyAwIDogaG91cikgOiAoaG91ciA9PT0gMTIgPyAxMiA6IGhvdXIgKyAxMik7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBwcml2YXRlIGhhbmRsZU1vZGVsQ2hhbmdlKGNyb246IHN0cmluZykge1xyXG4gICAgaWYgKHRoaXMuaXNEaXJ0eSkge1xyXG4gICAgICB0aGlzLmlzRGlydHkgPSBmYWxzZTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgdGhpcy5pc0RpcnR5ID0gZmFsc2U7XHJcbiAgICB9XHJcblxyXG4gICAgdGhpcy52YWxpZGF0ZShjcm9uKTtcclxuXHJcbiAgICBsZXQgY3JvblNldmVuID0gY3JvbjtcclxuICAgIGlmICh0aGlzLm9wdGlvbnMucmVtb3ZlU2Vjb25kcykge1xyXG4gICAgICBjcm9uU2V2ZW4gPSBgMCAke2Nyb259YDtcclxuICAgIH1cclxuXHJcbiAgICBpZiAodGhpcy5vcHRpb25zLnJlbW92ZVllYXJzKSB7XHJcbiAgICAgIGNyb25TZXZlbiA9IGAke2Nyb25TZXZlbn0gKmA7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgW3NlY29uZHMsIG1pbnV0ZXMsIGhvdXJzLCBkYXlPZk1vbnRoLCBtb250aCwgZGF5T2ZXZWVrXSA9IGNyb25TZXZlbi5zcGxpdCgnICcpO1xyXG5cclxuICAgIGlmIChjcm9uU2V2ZW4ubWF0Y2goL1xcZCsgMFxcL1xcZCsgXFwqIDFcXC8xIFxcKiBcXD8gXFwqLykpIHtcclxuICAgICAgdGhpcy5hY3RpdmVUYWIgPSAnbWludXRlcyc7XHJcblxyXG4gICAgICB0aGlzLnN0YXRlLm1pbnV0ZXMubWludXRlcyA9IE51bWJlcihtaW51dGVzLnN1YnN0cmluZygyKSk7XHJcbiAgICAgIHRoaXMuc3RhdGUubWludXRlcy5zZWNvbmRzID0gTnVtYmVyKHNlY29uZHMpO1xyXG4gICAgfSBlbHNlIGlmIChjcm9uU2V2ZW4ubWF0Y2goL1xcZCsgXFxkKyAwXFwvXFxkKyAxXFwvMSBcXCogXFw/IFxcKi8pKSB7XHJcbiAgICAgIHRoaXMuYWN0aXZlVGFiID0gJ2hvdXJseSc7XHJcblxyXG4gICAgICB0aGlzLnN0YXRlLmhvdXJseS5ob3VycyA9IE51bWJlcihob3Vycy5zdWJzdHJpbmcoMikpO1xyXG4gICAgICB0aGlzLnN0YXRlLmhvdXJseS5taW51dGVzID0gTnVtYmVyKG1pbnV0ZXMpO1xyXG4gICAgICB0aGlzLnN0YXRlLmhvdXJseS5zZWNvbmRzID0gTnVtYmVyKHNlY29uZHMpO1xyXG4gICAgfSBlbHNlIGlmIChjcm9uU2V2ZW4ubWF0Y2goL1xcZCsgXFxkKyBcXGQrIDFcXC9cXGQrIFxcKiBcXD8gXFwqLykpIHtcclxuICAgICAgdGhpcy5hY3RpdmVUYWIgPSAnZGFpbHknO1xyXG5cclxuICAgICAgdGhpcy5zdGF0ZS5kYWlseS5zdWJUYWIgPSAnZXZlcnlEYXlzJztcclxuICAgICAgdGhpcy5zdGF0ZS5kYWlseS5ldmVyeURheXMuZGF5cyA9IE51bWJlcihkYXlPZk1vbnRoLnN1YnN0cmluZygyKSk7XHJcbiAgICAgIGNvbnN0IHBhcnNlZEhvdXJzID0gTnVtYmVyKGhvdXJzKTtcclxuICAgICAgdGhpcy5zdGF0ZS5kYWlseS5ldmVyeURheXMuaG91cnMgPSB0aGlzLmdldEFtUG1Ib3VyKHBhcnNlZEhvdXJzKTtcclxuICAgICAgdGhpcy5zdGF0ZS5kYWlseS5ldmVyeURheXMuaG91clR5cGUgPSB0aGlzLmdldEhvdXJUeXBlKHBhcnNlZEhvdXJzKTtcclxuICAgICAgdGhpcy5zdGF0ZS5kYWlseS5ldmVyeURheXMubWludXRlcyA9IE51bWJlcihtaW51dGVzKTtcclxuICAgICAgdGhpcy5zdGF0ZS5kYWlseS5ldmVyeURheXMuc2Vjb25kcyA9IE51bWJlcihzZWNvbmRzKTtcclxuICAgIH0gZWxzZSBpZiAoY3JvblNldmVuLm1hdGNoKC9cXGQrIFxcZCsgXFxkKyBcXD8gXFwqIE1PTi1GUkkgXFwqLykpIHtcclxuICAgICAgdGhpcy5hY3RpdmVUYWIgPSAnZGFpbHknO1xyXG5cclxuICAgICAgdGhpcy5zdGF0ZS5kYWlseS5zdWJUYWIgPSAnZXZlcnlXZWVrRGF5JztcclxuICAgICAgY29uc3QgcGFyc2VkSG91cnMgPSBOdW1iZXIoaG91cnMpO1xyXG4gICAgICB0aGlzLnN0YXRlLmRhaWx5LmV2ZXJ5V2Vla0RheS5ob3VycyA9IHRoaXMuZ2V0QW1QbUhvdXIocGFyc2VkSG91cnMpO1xyXG4gICAgICB0aGlzLnN0YXRlLmRhaWx5LmV2ZXJ5V2Vla0RheS5ob3VyVHlwZSA9IHRoaXMuZ2V0SG91clR5cGUocGFyc2VkSG91cnMpO1xyXG4gICAgICB0aGlzLnN0YXRlLmRhaWx5LmV2ZXJ5V2Vla0RheS5taW51dGVzID0gTnVtYmVyKG1pbnV0ZXMpO1xyXG4gICAgICB0aGlzLnN0YXRlLmRhaWx5LmV2ZXJ5V2Vla0RheS5zZWNvbmRzID0gTnVtYmVyKHNlY29uZHMpO1xyXG4gICAgfSBlbHNlIGlmIChjcm9uU2V2ZW4ubWF0Y2goL1xcZCsgXFxkKyBcXGQrIFxcPyBcXCogKE1PTnxUVUV8V0VEfFRIVXxGUkl8U0FUfFNVTikoLChNT058VFVFfFdFRHxUSFV8RlJJfFNBVHxTVU4pKSogXFwqLykpIHtcclxuICAgICAgdGhpcy5hY3RpdmVUYWIgPSAnd2Vla2x5JztcclxuICAgICAgdGhpcy5zZWxlY3RPcHRpb25zLmRheXMuZm9yRWFjaCh3ZWVrRGF5ID0+IHRoaXMuc3RhdGUud2Vla2x5W3dlZWtEYXldID0gZmFsc2UpO1xyXG4gICAgICBkYXlPZldlZWsuc3BsaXQoJywnKS5mb3JFYWNoKHdlZWtEYXkgPT4gdGhpcy5zdGF0ZS53ZWVrbHlbd2Vla0RheV0gPSB0cnVlKTtcclxuICAgICAgY29uc3QgcGFyc2VkSG91cnMgPSBOdW1iZXIoaG91cnMpO1xyXG4gICAgICB0aGlzLnN0YXRlLndlZWtseS5ob3VycyA9IHRoaXMuZ2V0QW1QbUhvdXIocGFyc2VkSG91cnMpO1xyXG4gICAgICB0aGlzLnN0YXRlLndlZWtseS5ob3VyVHlwZSA9IHRoaXMuZ2V0SG91clR5cGUocGFyc2VkSG91cnMpO1xyXG4gICAgICB0aGlzLnN0YXRlLndlZWtseS5taW51dGVzID0gTnVtYmVyKG1pbnV0ZXMpO1xyXG4gICAgICB0aGlzLnN0YXRlLndlZWtseS5zZWNvbmRzID0gTnVtYmVyKHNlY29uZHMpO1xyXG4gICAgfSBlbHNlIGlmIChjcm9uU2V2ZW4ubWF0Y2goL1xcZCsgXFxkKyBcXGQrIChcXGQrfEx8TFd8MVcpIDFcXC9cXGQrIFxcPyBcXCovKSkge1xyXG4gICAgICB0aGlzLmFjdGl2ZVRhYiA9ICdtb250aGx5JztcclxuICAgICAgdGhpcy5zdGF0ZS5tb250aGx5LnN1YlRhYiA9ICdzcGVjaWZpY0RheSc7XHJcblxyXG4gICAgICBpZiAoZGF5T2ZNb250aC5pbmRleE9mKCdXJykgIT09IC0xKSB7XHJcbiAgICAgICAgdGhpcy5zdGF0ZS5tb250aGx5LnNwZWNpZmljRGF5LmRheSA9IGRheU9mTW9udGguY2hhckF0KDApO1xyXG4gICAgICAgIHRoaXMuc3RhdGUubW9udGhseS5ydW5PbldlZWtkYXkgPSB0cnVlO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHRoaXMuc3RhdGUubW9udGhseS5zcGVjaWZpY0RheS5kYXkgPSBkYXlPZk1vbnRoO1xyXG4gICAgICB9XHJcblxyXG4gICAgICB0aGlzLnN0YXRlLm1vbnRobHkuc3BlY2lmaWNEYXkubW9udGhzID0gTnVtYmVyKG1vbnRoLnN1YnN0cmluZygyKSk7XHJcbiAgICAgIGNvbnN0IHBhcnNlZEhvdXJzID0gTnVtYmVyKGhvdXJzKTtcclxuICAgICAgdGhpcy5zdGF0ZS5tb250aGx5LnNwZWNpZmljRGF5LmhvdXJzID0gdGhpcy5nZXRBbVBtSG91cihwYXJzZWRIb3Vycyk7XHJcbiAgICAgIHRoaXMuc3RhdGUubW9udGhseS5zcGVjaWZpY0RheS5ob3VyVHlwZSA9IHRoaXMuZ2V0SG91clR5cGUocGFyc2VkSG91cnMpO1xyXG4gICAgICB0aGlzLnN0YXRlLm1vbnRobHkuc3BlY2lmaWNEYXkubWludXRlcyA9IE51bWJlcihtaW51dGVzKTtcclxuICAgICAgdGhpcy5zdGF0ZS5tb250aGx5LnNwZWNpZmljRGF5LnNlY29uZHMgPSBOdW1iZXIoc2Vjb25kcyk7XHJcbiAgICB9IGVsc2UgaWYgKGNyb25TZXZlbi5tYXRjaCgvXFxkKyBcXGQrIFxcZCsgXFw/IFxcZCtcXC9cXGQrIChNT058VFVFfFdFRHxUSFV8RlJJfFNBVHxTVU4pKCgjWzEtNV0pfEwpIFxcKi8pKSB7XHJcbiAgICAgIGNvbnN0IGRheSA9IGRheU9mV2Vlay5zdWJzdHIoMCwgMyk7XHJcbiAgICAgIGNvbnN0IG1vbnRoV2VlayA9IGRheU9mV2Vlay5zdWJzdHIoMyk7XHJcbiAgICAgIHRoaXMuYWN0aXZlVGFiID0gJ21vbnRobHknO1xyXG4gICAgICB0aGlzLnN0YXRlLm1vbnRobHkuc3ViVGFiID0gJ3NwZWNpZmljV2Vla0RheSc7XHJcbiAgICAgIHRoaXMuc3RhdGUubW9udGhseS5zcGVjaWZpY1dlZWtEYXkubW9udGhXZWVrID0gbW9udGhXZWVrO1xyXG4gICAgICB0aGlzLnN0YXRlLm1vbnRobHkuc3BlY2lmaWNXZWVrRGF5LmRheSA9IGRheTtcclxuXHJcbiAgICAgIGlmIChtb250aC5pbmRleE9mKCcvJykgIT09IC0xKSB7XHJcbiAgICAgICAgY29uc3QgW3N0YXJ0TW9udGgsIG1vbnRoc10gPSBtb250aC5zcGxpdCgnLycpLm1hcChOdW1iZXIpO1xyXG4gICAgICAgIHRoaXMuc3RhdGUubW9udGhseS5zcGVjaWZpY1dlZWtEYXkubW9udGhzID0gbW9udGhzO1xyXG4gICAgICAgIHRoaXMuc3RhdGUubW9udGhseS5zcGVjaWZpY1dlZWtEYXkuc3RhcnRNb250aCA9IHN0YXJ0TW9udGg7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGNvbnN0IHBhcnNlZEhvdXJzID0gTnVtYmVyKGhvdXJzKTtcclxuICAgICAgdGhpcy5zdGF0ZS5tb250aGx5LnNwZWNpZmljV2Vla0RheS5ob3VycyA9IHRoaXMuZ2V0QW1QbUhvdXIocGFyc2VkSG91cnMpO1xyXG4gICAgICB0aGlzLnN0YXRlLm1vbnRobHkuc3BlY2lmaWNXZWVrRGF5LmhvdXJUeXBlID0gdGhpcy5nZXRIb3VyVHlwZShwYXJzZWRIb3Vycyk7XHJcbiAgICAgIHRoaXMuc3RhdGUubW9udGhseS5zcGVjaWZpY1dlZWtEYXkubWludXRlcyA9IE51bWJlcihtaW51dGVzKTtcclxuICAgICAgdGhpcy5zdGF0ZS5tb250aGx5LnNwZWNpZmljV2Vla0RheS5zZWNvbmRzID0gTnVtYmVyKHNlY29uZHMpO1xyXG4gICAgfSBlbHNlIGlmIChjcm9uU2V2ZW4ubWF0Y2goL1xcZCsgXFxkKyBcXGQrIChcXGQrfEx8TFd8MVcpIFxcZCsgXFw/IFxcKi8pKSB7XHJcbiAgICAgIHRoaXMuYWN0aXZlVGFiID0gJ3llYXJseSc7XHJcbiAgICAgIHRoaXMuc3RhdGUueWVhcmx5LnN1YlRhYiA9ICdzcGVjaWZpY01vbnRoRGF5JztcclxuICAgICAgdGhpcy5zdGF0ZS55ZWFybHkuc3BlY2lmaWNNb250aERheS5tb250aCA9IE51bWJlcihtb250aCk7XHJcblxyXG4gICAgICBpZiAoZGF5T2ZNb250aC5pbmRleE9mKCdXJykgIT09IC0xKSB7XHJcbiAgICAgICAgdGhpcy5zdGF0ZS55ZWFybHkuc3BlY2lmaWNNb250aERheS5kYXkgPSBkYXlPZk1vbnRoLmNoYXJBdCgwKTtcclxuICAgICAgICB0aGlzLnN0YXRlLnllYXJseS5ydW5PbldlZWtkYXkgPSB0cnVlO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHRoaXMuc3RhdGUueWVhcmx5LnNwZWNpZmljTW9udGhEYXkuZGF5ID0gZGF5T2ZNb250aDtcclxuICAgICAgfVxyXG5cclxuICAgICAgY29uc3QgcGFyc2VkSG91cnMgPSBOdW1iZXIoaG91cnMpO1xyXG4gICAgICB0aGlzLnN0YXRlLnllYXJseS5zcGVjaWZpY01vbnRoRGF5LmhvdXJzID0gdGhpcy5nZXRBbVBtSG91cihwYXJzZWRIb3Vycyk7XHJcbiAgICAgIHRoaXMuc3RhdGUueWVhcmx5LnNwZWNpZmljTW9udGhEYXkuaG91clR5cGUgPSB0aGlzLmdldEhvdXJUeXBlKHBhcnNlZEhvdXJzKTtcclxuICAgICAgdGhpcy5zdGF0ZS55ZWFybHkuc3BlY2lmaWNNb250aERheS5taW51dGVzID0gTnVtYmVyKG1pbnV0ZXMpO1xyXG4gICAgICB0aGlzLnN0YXRlLnllYXJseS5zcGVjaWZpY01vbnRoRGF5LnNlY29uZHMgPSBOdW1iZXIoc2Vjb25kcyk7XHJcbiAgICB9IGVsc2UgaWYgKGNyb25TZXZlbi5tYXRjaCgvXFxkKyBcXGQrIFxcZCsgXFw/IFxcZCsgKE1PTnxUVUV8V0VEfFRIVXxGUkl8U0FUfFNVTikoKCNbMS01XSl8TCkgXFwqLykpIHtcclxuICAgICAgY29uc3QgZGF5ID0gZGF5T2ZXZWVrLnN1YnN0cigwLCAzKTtcclxuICAgICAgY29uc3QgbW9udGhXZWVrID0gZGF5T2ZXZWVrLnN1YnN0cigzKTtcclxuICAgICAgdGhpcy5hY3RpdmVUYWIgPSAneWVhcmx5JztcclxuICAgICAgdGhpcy5zdGF0ZS55ZWFybHkuc3ViVGFiID0gJ3NwZWNpZmljTW9udGhXZWVrJztcclxuICAgICAgdGhpcy5zdGF0ZS55ZWFybHkuc3BlY2lmaWNNb250aFdlZWsubW9udGhXZWVrID0gbW9udGhXZWVrO1xyXG4gICAgICB0aGlzLnN0YXRlLnllYXJseS5zcGVjaWZpY01vbnRoV2Vlay5kYXkgPSBkYXk7XHJcbiAgICAgIHRoaXMuc3RhdGUueWVhcmx5LnNwZWNpZmljTW9udGhXZWVrLm1vbnRoID0gTnVtYmVyKG1vbnRoKTtcclxuICAgICAgY29uc3QgcGFyc2VkSG91cnMgPSBOdW1iZXIoaG91cnMpO1xyXG4gICAgICB0aGlzLnN0YXRlLnllYXJseS5zcGVjaWZpY01vbnRoV2Vlay5ob3VycyA9IHRoaXMuZ2V0QW1QbUhvdXIocGFyc2VkSG91cnMpO1xyXG4gICAgICB0aGlzLnN0YXRlLnllYXJseS5zcGVjaWZpY01vbnRoV2Vlay5ob3VyVHlwZSA9IHRoaXMuZ2V0SG91clR5cGUocGFyc2VkSG91cnMpO1xyXG4gICAgICB0aGlzLnN0YXRlLnllYXJseS5zcGVjaWZpY01vbnRoV2Vlay5taW51dGVzID0gTnVtYmVyKG1pbnV0ZXMpO1xyXG4gICAgICB0aGlzLnN0YXRlLnllYXJseS5zcGVjaWZpY01vbnRoV2Vlay5zZWNvbmRzID0gTnVtYmVyKHNlY29uZHMpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgdGhpcy5hY3RpdmVUYWIgPSAnYWR2YW5jZWQnO1xyXG4gICAgICB0aGlzLnN0YXRlLmFkdmFuY2VkLmV4cHJlc3Npb24gPSBjcm9uO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcHJpdmF0ZSB2YWxpZGF0ZShjcm9uOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgIHRoaXMuc3RhdGUudmFsaWRhdGlvbi5pc1ZhbGlkID0gZmFsc2U7XHJcbiAgICB0aGlzLnN0YXRlLnZhbGlkYXRpb24uZXJyb3JNZXNzYWdlID0gJyc7XHJcblxyXG4gICAgaWYgKCFjcm9uKSB7XHJcbiAgICAgIHRoaXMuc3RhdGUudmFsaWRhdGlvbi5lcnJvck1lc3NhZ2UgPSAnQ3JvbiBleHByZXNzaW9uIGNhbm5vdCBiZSBudWxsJztcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGNyb25QYXJ0cyA9IGNyb24uc3BsaXQoJyAnKTtcclxuXHJcbiAgICBsZXQgZXhwZWN0ZWQgPSA1O1xyXG5cclxuICAgIGlmICghdGhpcy5vcHRpb25zLnJlbW92ZVNlY29uZHMpIHtcclxuICAgICAgZXhwZWN0ZWQrKztcclxuICAgIH1cclxuXHJcbiAgICBpZiAoIXRoaXMub3B0aW9ucy5yZW1vdmVZZWFycykge1xyXG4gICAgICBleHBlY3RlZCsrO1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChjcm9uUGFydHMubGVuZ3RoICE9PSBleHBlY3RlZCkge1xyXG4gICAgICB0aGlzLnN0YXRlLnZhbGlkYXRpb24uZXJyb3JNZXNzYWdlID0gYEludmFsaWQgY3JvbiBleHByZXNzaW9uLCB0aGVyZSBtdXN0IGJlICR7ZXhwZWN0ZWR9IHNlZ21lbnRzYDtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHRoaXMuc3RhdGUudmFsaWRhdGlvbi5pc1ZhbGlkID0gdHJ1ZTtcclxuICAgIHJldHVybjtcclxuICB9XHJcblxyXG4gIHByaXZhdGUgZ2V0RGVmYXVsdEFkdmFuY2VkQ3JvbkV4cHJlc3Npb24oKTogc3RyaW5nIHtcclxuICAgIGlmICh0aGlzLm9wdGlvbnMucmVtb3ZlU2Vjb25kcyAmJiAhdGhpcy5vcHRpb25zLnJlbW92ZVllYXJzKSB7XHJcbiAgICAgIHJldHVybiAnMTUgMTAgTC0yICogPyAyMDE5JztcclxuICAgIH1cclxuXHJcbiAgICBpZiAoIXRoaXMub3B0aW9ucy5yZW1vdmVTZWNvbmRzICYmIHRoaXMub3B0aW9ucy5yZW1vdmVZZWFycykge1xyXG4gICAgICByZXR1cm4gJzAgMTUgMTAgTC0yICogPyc7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKHRoaXMub3B0aW9ucy5yZW1vdmVTZWNvbmRzICYmIHRoaXMub3B0aW9ucy5yZW1vdmVZZWFycykge1xyXG4gICAgICByZXR1cm4gJzE1IDEwIEwtMiAqID8nO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiAnMCAxNSAxMCBMLTIgKiA/IDIwMTknO1xyXG4gIH1cclxuXHJcbiAgcHJpdmF0ZSBnZXREZWZhdWx0U3RhdGUoKSB7XHJcbiAgICBjb25zdCBbZGVmYXVsdEhvdXJzLCBkZWZhdWx0TWludXRlcywgZGVmYXVsdFNlY29uZHNdID0gdGhpcy5vcHRpb25zLmRlZmF1bHRUaW1lLnNwbGl0KCc6JykubWFwKE51bWJlcik7XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgbWludXRlczoge1xyXG4gICAgICAgIG1pbnV0ZXM6IDEsXHJcbiAgICAgICAgc2Vjb25kczogMFxyXG4gICAgICB9LFxyXG4gICAgICBob3VybHk6IHtcclxuICAgICAgICBob3VyczogMSxcclxuICAgICAgICBtaW51dGVzOiAwLFxyXG4gICAgICAgIHNlY29uZHM6IDBcclxuICAgICAgfSxcclxuICAgICAgZGFpbHk6IHtcclxuICAgICAgICBzdWJUYWI6ICdldmVyeURheXMnLFxyXG4gICAgICAgIGV2ZXJ5RGF5czoge1xyXG4gICAgICAgICAgZGF5czogMSxcclxuICAgICAgICAgIGhvdXJzOiB0aGlzLmdldEFtUG1Ib3VyKGRlZmF1bHRIb3VycyksXHJcbiAgICAgICAgICBtaW51dGVzOiBkZWZhdWx0TWludXRlcyxcclxuICAgICAgICAgIHNlY29uZHM6IGRlZmF1bHRTZWNvbmRzLFxyXG4gICAgICAgICAgaG91clR5cGU6IHRoaXMuZ2V0SG91clR5cGUoZGVmYXVsdEhvdXJzKVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgZXZlcnlXZWVrRGF5OiB7XHJcbiAgICAgICAgICBob3VyczogdGhpcy5nZXRBbVBtSG91cihkZWZhdWx0SG91cnMpLFxyXG4gICAgICAgICAgbWludXRlczogZGVmYXVsdE1pbnV0ZXMsXHJcbiAgICAgICAgICBzZWNvbmRzOiBkZWZhdWx0U2Vjb25kcyxcclxuICAgICAgICAgIGhvdXJUeXBlOiB0aGlzLmdldEhvdXJUeXBlKGRlZmF1bHRIb3VycylcclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcbiAgICAgIHdlZWtseToge1xyXG4gICAgICAgIE1PTjogdHJ1ZSxcclxuICAgICAgICBUVUU6IGZhbHNlLFxyXG4gICAgICAgIFdFRDogZmFsc2UsXHJcbiAgICAgICAgVEhVOiBmYWxzZSxcclxuICAgICAgICBGUkk6IGZhbHNlLFxyXG4gICAgICAgIFNBVDogZmFsc2UsXHJcbiAgICAgICAgU1VOOiBmYWxzZSxcclxuICAgICAgICBob3VyczogdGhpcy5nZXRBbVBtSG91cihkZWZhdWx0SG91cnMpLFxyXG4gICAgICAgIG1pbnV0ZXM6IGRlZmF1bHRNaW51dGVzLFxyXG4gICAgICAgIHNlY29uZHM6IGRlZmF1bHRTZWNvbmRzLFxyXG4gICAgICAgIGhvdXJUeXBlOiB0aGlzLmdldEhvdXJUeXBlKGRlZmF1bHRIb3VycylcclxuICAgICAgfSxcclxuICAgICAgbW9udGhseToge1xyXG4gICAgICAgIHN1YlRhYjogJ3NwZWNpZmljRGF5JyxcclxuICAgICAgICBydW5PbldlZWtkYXk6IGZhbHNlLFxyXG4gICAgICAgIHNwZWNpZmljRGF5OiB7XHJcbiAgICAgICAgICBkYXk6ICcxJyxcclxuICAgICAgICAgIG1vbnRoczogMSxcclxuICAgICAgICAgIGhvdXJzOiB0aGlzLmdldEFtUG1Ib3VyKGRlZmF1bHRIb3VycyksXHJcbiAgICAgICAgICBtaW51dGVzOiBkZWZhdWx0TWludXRlcyxcclxuICAgICAgICAgIHNlY29uZHM6IGRlZmF1bHRTZWNvbmRzLFxyXG4gICAgICAgICAgaG91clR5cGU6IHRoaXMuZ2V0SG91clR5cGUoZGVmYXVsdEhvdXJzKVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgc3BlY2lmaWNXZWVrRGF5OiB7XHJcbiAgICAgICAgICBtb250aFdlZWs6ICcjMScsXHJcbiAgICAgICAgICBkYXk6ICdNT04nLFxyXG4gICAgICAgICAgc3RhcnRNb250aDogMSxcclxuICAgICAgICAgIG1vbnRoczogMSxcclxuICAgICAgICAgIGhvdXJzOiB0aGlzLmdldEFtUG1Ib3VyKGRlZmF1bHRIb3VycyksXHJcbiAgICAgICAgICBtaW51dGVzOiBkZWZhdWx0TWludXRlcyxcclxuICAgICAgICAgIHNlY29uZHM6IGRlZmF1bHRTZWNvbmRzLFxyXG4gICAgICAgICAgaG91clR5cGU6IHRoaXMuZ2V0SG91clR5cGUoZGVmYXVsdEhvdXJzKVxyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuICAgICAgeWVhcmx5OiB7XHJcbiAgICAgICAgc3ViVGFiOiAnc3BlY2lmaWNNb250aERheScsXHJcbiAgICAgICAgcnVuT25XZWVrZGF5OiBmYWxzZSxcclxuICAgICAgICBzcGVjaWZpY01vbnRoRGF5OiB7XHJcbiAgICAgICAgICBtb250aDogMSxcclxuICAgICAgICAgIGRheTogJzEnLFxyXG4gICAgICAgICAgaG91cnM6IHRoaXMuZ2V0QW1QbUhvdXIoZGVmYXVsdEhvdXJzKSxcclxuICAgICAgICAgIG1pbnV0ZXM6IGRlZmF1bHRNaW51dGVzLFxyXG4gICAgICAgICAgc2Vjb25kczogZGVmYXVsdFNlY29uZHMsXHJcbiAgICAgICAgICBob3VyVHlwZTogdGhpcy5nZXRIb3VyVHlwZShkZWZhdWx0SG91cnMpXHJcbiAgICAgICAgfSxcclxuICAgICAgICBzcGVjaWZpY01vbnRoV2Vlazoge1xyXG4gICAgICAgICAgbW9udGhXZWVrOiAnIzEnLFxyXG4gICAgICAgICAgZGF5OiAnTU9OJyxcclxuICAgICAgICAgIG1vbnRoOiAxLFxyXG4gICAgICAgICAgaG91cnM6IHRoaXMuZ2V0QW1QbUhvdXIoZGVmYXVsdEhvdXJzKSxcclxuICAgICAgICAgIG1pbnV0ZXM6IGRlZmF1bHRNaW51dGVzLFxyXG4gICAgICAgICAgc2Vjb25kczogZGVmYXVsdFNlY29uZHMsXHJcbiAgICAgICAgICBob3VyVHlwZTogdGhpcy5nZXRIb3VyVHlwZShkZWZhdWx0SG91cnMpXHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgICBhZHZhbmNlZDoge1xyXG4gICAgICAgIGV4cHJlc3Npb246IHRoaXMuZ2V0RGVmYXVsdEFkdmFuY2VkQ3JvbkV4cHJlc3Npb24oKVxyXG4gICAgICB9LFxyXG4gICAgICB2YWxpZGF0aW9uOiB7XHJcbiAgICAgICAgaXNWYWxpZDogdHJ1ZSxcclxuICAgICAgICBlcnJvck1lc3NhZ2U6ICcnXHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgfVxyXG5cclxuICBwcml2YXRlIGdldE9yZGluYWxTdWZmaXgodmFsdWU6IHN0cmluZykge1xyXG4gICAgaWYgKHZhbHVlLmxlbmd0aCA+IDEpIHtcclxuICAgICAgY29uc3Qgc2Vjb25kVG9MYXN0RGlnaXQgPSB2YWx1ZS5jaGFyQXQodmFsdWUubGVuZ3RoIC0gMik7XHJcbiAgICAgIGlmIChzZWNvbmRUb0xhc3REaWdpdCA9PT0gJzEnKSB7XHJcbiAgICAgICAgcmV0dXJuICd0aCc7XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBsYXN0RGlnaXQgPSB2YWx1ZS5jaGFyQXQodmFsdWUubGVuZ3RoIC0gMSk7XHJcbiAgICBzd2l0Y2ggKGxhc3REaWdpdCkge1xyXG4gICAgICBjYXNlICcxJzpcclxuICAgICAgICByZXR1cm4gJ3N0JztcclxuICAgICAgY2FzZSAnMic6XHJcbiAgICAgICAgcmV0dXJuICduZCc7XHJcbiAgICAgIGNhc2UgJzMnOlxyXG4gICAgICAgIHJldHVybiAncmQnO1xyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHJldHVybiAndGgnO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcHJpdmF0ZSBnZXRTZWxlY3RPcHRpb25zKCkge1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgbW9udGhzOiBVdGlscy5nZXRSYW5nZSgxLCAxMiksXHJcbiAgICAgIG1vbnRoV2Vla3M6IFsnIzEnLCAnIzInLCAnIzMnLCAnIzQnLCAnIzUnLCAnTCddLFxyXG4gICAgICBkYXlzOiBbJ01PTicsICdUVUUnLCAnV0VEJywgJ1RIVScsICdGUkknLCAnU0FUJywgJ1NVTiddLFxyXG4gICAgICBtaW51dGVzOiBVdGlscy5nZXRSYW5nZSgwLCA1OSksXHJcbiAgICAgIGZ1bGxNaW51dGVzOiBVdGlscy5nZXRSYW5nZSgwLCA1OSksXHJcbiAgICAgIHNlY29uZHM6IFV0aWxzLmdldFJhbmdlKDAsIDU5KSxcclxuICAgICAgaG91cnM6IFV0aWxzLmdldFJhbmdlKDEsIDIzKSxcclxuICAgICAgbW9udGhEYXlzOiBVdGlscy5nZXRSYW5nZSgxLCAzMSksXHJcbiAgICAgIG1vbnRoRGF5c1dpdGhMYXN0czogWy4uLlV0aWxzLmdldFJhbmdlKDEsIDMxKS5tYXAoU3RyaW5nKSwgJ0wnXSxcclxuICAgICAgaG91clR5cGVzOiBbJ0FNJywgJ1BNJ11cclxuICAgIH07XHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0LCBPdXRwdXQsIEV2ZW50RW1pdHRlciwgSW5wdXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbmltcG9ydCBVdGlscyBmcm9tICcuLi9VdGlscyc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogJ2Nyb24tdGltZS1waWNrZXInLFxyXG4gIHRlbXBsYXRlVXJsOiAnLi90aW1lLXBpY2tlci5jb21wb25lbnQuaHRtbCcsXHJcbiAgc3R5bGVVcmxzOiBbJy4vdGltZS1waWNrZXIuY29tcG9uZW50LmNzcyddXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBUaW1lUGlja2VyQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcclxuICBAT3V0cHV0KCkgcHVibGljIGNoYW5nZSA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuICBASW5wdXQoKSBwdWJsaWMgZGlzYWJsZWQ6IGJvb2xlYW47XHJcbiAgQElucHV0KCkgcHVibGljIHRpbWU6IGFueTtcclxuICBASW5wdXQoKSBwdWJsaWMgc2VsZWN0Q2xhc3M6IHN0cmluZztcclxuICBASW5wdXQoKSBwdWJsaWMgdXNlMjRIb3VyVGltZTogYm9vbGVhbjtcclxuICBASW5wdXQoKSBwdWJsaWMgaGlkZVNlY29uZHM6IGJvb2xlYW47XHJcblxyXG4gIHB1YmxpYyBob3VyczogbnVtYmVyW107XHJcbiAgcHVibGljIG1pbnV0ZXM6IG51bWJlcltdO1xyXG4gIHB1YmxpYyBzZWNvbmRzOiBudW1iZXJbXTtcclxuICBwdWJsaWMgaG91clR5cGVzOiBzdHJpbmdbXTtcclxuXHJcbiAgcHVibGljIG5nT25Jbml0KCkge1xyXG4gICAgdGhpcy5ob3VycyA9IHRoaXMudXNlMjRIb3VyVGltZSA/IFV0aWxzLmdldFJhbmdlKDAsIDIzKSA6IFV0aWxzLmdldFJhbmdlKDAsIDEyKTtcclxuICAgIHRoaXMubWludXRlcyA9IFV0aWxzLmdldFJhbmdlKDAsIDU5KTtcclxuICAgIHRoaXMuc2Vjb25kcyA9IFV0aWxzLmdldFJhbmdlKDAsIDU5KTtcclxuICAgIHRoaXMuaG91clR5cGVzID0gWydBTScsICdQTSddO1xyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBGb3Jtc01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcclxuaW1wb3J0IHsgQ29tbW9uTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcclxuXHJcbmltcG9ydCB7IENyb25FZGl0b3JDb21wb25lbnQgfSBmcm9tICcuL2Nyb24tZWRpdG9yLmNvbXBvbmVudCc7XHJcbmltcG9ydCB7IFRpbWVQaWNrZXJDb21wb25lbnQgfSBmcm9tICcuL3RpbWUtcGlja2VyL3RpbWUtcGlja2VyLmNvbXBvbmVudCc7XHJcblxyXG5ATmdNb2R1bGUoe1xyXG4gIGRlY2xhcmF0aW9uczogW0Nyb25FZGl0b3JDb21wb25lbnQsIFRpbWVQaWNrZXJDb21wb25lbnRdLFxyXG4gIGltcG9ydHM6IFtDb21tb25Nb2R1bGUsIEZvcm1zTW9kdWxlXSxcclxuICBleHBvcnRzOiBbQ3JvbkVkaXRvckNvbXBvbmVudF1cclxufSlcclxuZXhwb3J0IGNsYXNzIENyb25FZGl0b3JNb2R1bGUgeyB9XHJcbiJdLCJuYW1lcyI6WyJFdmVudEVtaXR0ZXIiLCJDb21wb25lbnQiLCJJbnB1dCIsIk91dHB1dCIsIk5nTW9kdWxlIiwiQ29tbW9uTW9kdWxlIiwiRm9ybXNNb2R1bGUiXSwibWFwcGluZ3MiOiI7Ozs7OztJQUFBOzs7Ozs7Ozs7Ozs7OztBQWNBLGFBdUdnQixNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUM7UUFDdkIsSUFBSSxDQUFDLEdBQUcsT0FBTyxNQUFNLEtBQUssVUFBVSxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDM0QsSUFBSSxDQUFDLENBQUM7WUFBRSxPQUFPLENBQUMsQ0FBQztRQUNqQixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLEdBQUcsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUNqQyxJQUFJO1lBQ0EsT0FBTyxDQUFDLENBQUMsS0FBSyxLQUFLLENBQUMsSUFBSSxDQUFDLEVBQUUsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxFQUFFLEVBQUUsSUFBSTtnQkFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUM5RTtRQUNELE9BQU8sS0FBSyxFQUFFO1lBQUUsQ0FBQyxHQUFHLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxDQUFDO1NBQUU7Z0JBQy9CO1lBQ0osSUFBSTtnQkFDQSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ3BEO29CQUNPO2dCQUFFLElBQUksQ0FBQztvQkFBRSxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUM7YUFBRTtTQUNwQztRQUNELE9BQU8sRUFBRSxDQUFDO0lBQ2QsQ0FBQztBQUVELGFBQWdCLFFBQVE7UUFDcEIsS0FBSyxJQUFJLEVBQUUsR0FBRyxFQUFFLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsU0FBUyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUU7WUFDOUMsRUFBRSxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDekMsT0FBTyxFQUFFLENBQUM7SUFDZCxDQUFDOzs7Ozs7O0FDMUlELFFBQWEsSUFBSSxHQUFHO1FBQ2hCLEtBQUssRUFBRSxRQUFRO1FBQ2YsS0FBSyxFQUFFLFFBQVE7UUFDZixLQUFLLEVBQUUsU0FBUztRQUNoQixLQUFLLEVBQUUsV0FBVztRQUNsQixLQUFLLEVBQUUsVUFBVTtRQUNqQixLQUFLLEVBQUUsUUFBUTtRQUNmLEtBQUssRUFBRSxVQUFVO0tBQ3BCOztBQUVELFFBQWEsVUFBVSxHQUFHO1FBQ3RCLElBQUksRUFBRSxPQUFPO1FBQ2IsSUFBSSxFQUFFLFFBQVE7UUFDZCxJQUFJLEVBQUUsT0FBTztRQUNiLElBQUksRUFBRSxRQUFRO1FBQ2QsSUFBSSxFQUFFLE9BQU87UUFDYixHQUFHLEVBQUUsTUFBTTtLQUNkOzs7UUFHRyxVQUFXO1FBQ1gsV0FBUTtRQUNSLFFBQUs7UUFDTCxRQUFLO1FBQ0wsTUFBRztRQUNILE9BQUk7UUFDSixPQUFJO1FBQ0osU0FBTTtRQUNOLFlBQVM7UUFDVCxXQUFPO1FBQ1AsWUFBUTtRQUNSLFlBQVE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0lDOUJaOzs7UUFBQTtTQUtDOzs7Ozs7OztRQUhpQixjQUFROzs7Ozs7WUFBdEIsVUFBdUIsU0FBaUIsRUFBRSxLQUFhO2dCQUNuRCxPQUFPLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBRSxNQUFNLEdBQUcsS0FBSyxHQUFHLENBQUMsR0FBRyxTQUFTLENBQUMsRUFBRSxFQUFFLFVBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSyxPQUFBLENBQUMsR0FBRyxTQUFTLEdBQUEsQ0FBQyxDQUFDO2FBQ25GO1FBQ0wsWUFBQztJQUFELENBQUMsSUFBQTs7Ozs7OztRQ0FEOztZQWdCWSxlQUFVLEdBQUcsSUFBSUEsaUJBQVksRUFBRSxDQUFDO1lBR25DLGtCQUFhLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7U0F1Z0JoRDtRQWpoQkMsc0JBQWEscUNBQUk7OztnQkFBakIsY0FBOEIsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUU7Ozs7Z0JBQ3RELFVBQVMsS0FBYTtnQkFDcEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7Z0JBQ3ZCLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQzthQUN0Qzs7O1dBSnFEOzs7O1FBZ0IvQyxzQ0FBUTs7O1lBQWY7Z0JBQ0UsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRTtvQkFDOUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDO2lCQUNqQztnQkFFRCxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztnQkFFcEMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUNuQzs7Ozs7UUFFTSx5Q0FBVzs7OztZQUFsQixVQUFtQixPQUFzQjs7b0JBQ2pDLE9BQU8sR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDO2dCQUMvQixJQUFJLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUU7b0JBQ25DLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7aUJBQ25DO2FBQ0Y7Ozs7O1FBRU0sMENBQVk7Ozs7WUFBbkIsVUFBb0IsR0FBVztnQkFDN0IsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUU7b0JBQ2xCLElBQUksQ0FBQyxTQUFTLEdBQUcsR0FBRyxDQUFDO29CQUNyQixJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7aUJBQ3ZCO2FBQ0Y7Ozs7O1FBRU0sd0NBQVU7Ozs7WUFBakIsVUFBa0IsR0FBVztnQkFDM0IsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7YUFDbEI7Ozs7O1FBRU0sOENBQWdCOzs7O1lBQXZCLFVBQXdCLGVBQXVCO2dCQUM3QyxPQUFPLFVBQVUsQ0FBQyxlQUFlLENBQUMsQ0FBQzthQUNwQzs7Ozs7UUFFTSwwQ0FBWTs7OztZQUFuQixVQUFvQixLQUFhO2dCQUMvQixPQUFPLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0Qjs7Ozs7UUFFTSw2Q0FBZTs7OztZQUF0QixVQUF1QixLQUFhO2dCQUNsQyxJQUFJLEtBQUssS0FBSyxHQUFHLEVBQUU7b0JBQ2pCLE9BQU8sVUFBVSxDQUFDO2lCQUNuQjtxQkFBTSxJQUFJLEtBQUssS0FBSyxJQUFJLEVBQUU7b0JBQ3pCLE9BQU8sY0FBYyxDQUFDO2lCQUN2QjtxQkFBTSxJQUFJLEtBQUssS0FBSyxJQUFJLEVBQUU7b0JBQ3pCLE9BQU8sZUFBZSxDQUFDO2lCQUN4QjtxQkFBTTtvQkFDTCxPQUFPLEtBQUcsS0FBSyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsU0FBTSxDQUFDO2lCQUN0RDthQUNGOzs7O1FBRU0sNENBQWM7OztZQUFyQjtnQkFBQSxpQkEySUM7Z0JBMUlDLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO2dCQUVwQixRQUFRLElBQUksQ0FBQyxTQUFTO29CQUNwQixLQUFLLFNBQVM7d0JBQ1osSUFBSSxDQUFDLElBQUksR0FBRyxPQUFLLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sZUFBWSxDQUFDO3dCQUV4RCxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUU7NEJBQy9CLElBQUksQ0FBQyxJQUFJLEdBQU0sSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxTQUFJLElBQUksQ0FBQyxJQUFNLENBQUM7eUJBQzFEO3dCQUVELElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRTs0QkFDN0IsSUFBSSxDQUFDLElBQUksR0FBTSxJQUFJLENBQUMsSUFBSSxPQUFJLENBQUM7eUJBQzlCO3dCQUNELE1BQU07b0JBQ1IsS0FBSyxRQUFRO3dCQUNYLElBQUksQ0FBQyxJQUFJLEdBQU0sSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxXQUFNLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUssYUFBVSxDQUFDO3dCQUVoRixJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUU7NEJBQy9CLElBQUksQ0FBQyxJQUFJLEdBQU0sSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxTQUFJLElBQUksQ0FBQyxJQUFNLENBQUM7eUJBQ3pEO3dCQUVELElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRTs0QkFDN0IsSUFBSSxDQUFDLElBQUksR0FBTSxJQUFJLENBQUMsSUFBSSxPQUFJLENBQUM7eUJBQzlCO3dCQUNELE1BQU07b0JBQ1IsS0FBSyxPQUFPO3dCQUNWLFFBQVEsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTTs0QkFDN0IsS0FBSyxXQUFXOztnQ0FFZCxJQUFJLENBQUMsSUFBSSxHQUFNLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxPQUFPLFNBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsV0FBTSxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsSUFBSSxTQUFNLENBQUM7Z0NBRXZMLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRTtvQ0FDL0IsSUFBSSxDQUFDLElBQUksR0FBTSxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsT0FBTyxTQUFJLElBQUksQ0FBQyxJQUFNLENBQUM7aUNBQ2xFO2dDQUVELElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRTtvQ0FDN0IsSUFBSSxDQUFDLElBQUksR0FBTSxJQUFJLENBQUMsSUFBSSxPQUFJLENBQUM7aUNBQzlCO2dDQUNELE1BQU07NEJBQ1IsS0FBSyxjQUFjOztnQ0FFakIsSUFBSSxDQUFDLElBQUksR0FBTSxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsT0FBTyxTQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLGlCQUFjLENBQUM7Z0NBRW5LLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRTtvQ0FDL0IsSUFBSSxDQUFDLElBQUksR0FBTSxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsT0FBTyxTQUFJLElBQUksQ0FBQyxJQUFNLENBQUM7aUNBQ3JFO2dDQUVELElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRTtvQ0FDN0IsSUFBSSxDQUFDLElBQUksR0FBTSxJQUFJLENBQUMsSUFBSSxPQUFJLENBQUM7aUNBQzlCO2dDQUNELE1BQU07NEJBQ1I7Z0NBQ0UsTUFBTSxJQUFJLEtBQUssQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFDO3lCQUMxRDt3QkFDRCxNQUFNO29CQUNSLEtBQUssUUFBUTs7NEJBQ0wsSUFBSSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSTs2QkFDakMsTUFBTSxDQUFDLFVBQUMsR0FBRyxFQUFFLEdBQUcsSUFBSyxPQUFBLEtBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBQSxFQUFFLEVBQUUsQ0FBQzs2QkFDMUUsSUFBSSxDQUFDLEdBQUcsQ0FBQzt3QkFDWixJQUFJLENBQUMsSUFBSSxHQUFNLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU8sU0FBSSxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsYUFBUSxJQUFNLENBQUM7d0JBRS9ILElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRTs0QkFDL0IsSUFBSSxDQUFDLElBQUksR0FBTSxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLFNBQUksSUFBSSxDQUFDLElBQU0sQ0FBQzt5QkFDekQ7d0JBRUQsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFOzRCQUM3QixJQUFJLENBQUMsSUFBSSxHQUFNLElBQUksQ0FBQyxJQUFJLE9BQUksQ0FBQzt5QkFDOUI7d0JBQ0QsTUFBTTtvQkFDUixLQUFLLFNBQVM7d0JBQ1osUUFBUSxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNOzRCQUMvQixLQUFLLGFBQWE7O29DQUNWLEdBQUcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxZQUFZLEdBQU0sSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLEdBQUcsTUFBRyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxHQUFHOztnQ0FFM0gsSUFBSSxDQUFDLElBQUksR0FBTSxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsT0FBTyxTQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLFNBQUksR0FBRyxXQUFNLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxNQUFNLE9BQUksQ0FBQztnQ0FFOU0sSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFO29DQUMvQixJQUFJLENBQUMsSUFBSSxHQUFNLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxPQUFPLFNBQUksSUFBSSxDQUFDLElBQU0sQ0FBQztpQ0FDdEU7Z0NBRUQsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFO29DQUM3QixJQUFJLENBQUMsSUFBSSxHQUFNLElBQUksQ0FBQyxJQUFJLE9BQUksQ0FBQztpQ0FDOUI7Z0NBQ0QsTUFBTTs0QkFDUixLQUFLLGlCQUFpQjs7Z0NBRXBCLElBQUksQ0FBQyxJQUFJLEdBQU0sSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLE9BQU8sU0FBSSxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxXQUFNLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxVQUFVLFNBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLE1BQU0sU0FBSSxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxTQUFXLENBQUM7Z0NBRS9WLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRTtvQ0FDL0IsSUFBSSxDQUFDLElBQUksR0FBTSxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsT0FBTyxTQUFJLElBQUksQ0FBQyxJQUFNLENBQUM7aUNBQzFFO2dDQUVELElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRTtvQ0FDN0IsSUFBSSxDQUFDLElBQUksR0FBTSxJQUFJLENBQUMsSUFBSSxPQUFJLENBQUM7aUNBQzlCO2dDQUNELE1BQU07NEJBQ1I7Z0NBQ0UsTUFBTSxJQUFJLEtBQUssQ0FBQyx1Q0FBdUMsQ0FBQyxDQUFDO3lCQUM1RDt3QkFDRCxNQUFNO29CQUNSLEtBQUssUUFBUTt3QkFDWCxRQUFRLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE1BQU07NEJBQzlCLEtBQUssa0JBQWtCOzs7b0NBRWYsR0FBRyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLFlBQVksR0FBTSxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLE1BQUcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHOztnQ0FFbEksSUFBSSxDQUFDLElBQUksR0FBTSxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLFNBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLFNBQUksR0FBRyxTQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLEtBQUssT0FBSSxDQUFDO2dDQUUzTixJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUU7b0NBQy9CLElBQUksQ0FBQyxJQUFJLEdBQU0sSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxTQUFJLElBQUksQ0FBQyxJQUFNLENBQUM7aUNBQzFFO2dDQUVELElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRTtvQ0FDN0IsSUFBSSxDQUFDLElBQUksR0FBTSxJQUFJLENBQUMsSUFBSSxPQUFJLENBQUM7aUNBQzlCO2dDQUNELE1BQU07NEJBQ1IsS0FBSyxtQkFBbUI7O2dDQUV0QixJQUFJLENBQUMsSUFBSSxHQUFNLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sU0FBSSxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsV0FBTSxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLFNBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLFNBQVcsQ0FBQztnQ0FFblQsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFO29DQUMvQixJQUFJLENBQUMsSUFBSSxHQUFNLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sU0FBSSxJQUFJLENBQUMsSUFBTSxDQUFDO2lDQUMzRTtnQ0FFRCxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUU7b0NBQzdCLElBQUksQ0FBQyxJQUFJLEdBQU0sSUFBSSxDQUFDLElBQUksT0FBSSxDQUFDO2lDQUM5QjtnQ0FDRCxNQUFNOzRCQUNSO2dDQUNFLE1BQU0sSUFBSSxLQUFLLENBQUMsc0NBQXNDLENBQUMsQ0FBQzt5QkFDM0Q7d0JBQ0QsTUFBTTtvQkFDUixLQUFLLFVBQVU7d0JBQ2IsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUM7d0JBQzNDLE1BQU07b0JBQ1I7d0JBQ0UsTUFBTSxJQUFJLEtBQUssQ0FBQyxtQ0FBbUMsQ0FBQyxDQUFDO2lCQUN4RDthQUNGOzs7Ozs7UUFFTyx5Q0FBVzs7Ozs7WUFBbkIsVUFBb0IsSUFBWTtnQkFDOUIsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsR0FBRyxJQUFJLEdBQUcsQ0FBQyxJQUFJLEdBQUcsRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLENBQUM7YUFDakU7Ozs7OztRQUVPLHlDQUFXOzs7OztZQUFuQixVQUFvQixJQUFZO2dCQUM5QixPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxHQUFHLFNBQVMsSUFBSSxJQUFJLElBQUksRUFBRSxHQUFHLElBQUksR0FBRyxJQUFJLENBQUMsQ0FBQzthQUM1RTs7Ozs7OztRQUVPLHdDQUFVOzs7Ozs7WUFBbEIsVUFBbUIsSUFBWSxFQUFFLFFBQWdCO2dCQUMvQyxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFO29CQUM5QixPQUFPLElBQUksQ0FBQztpQkFDYjtxQkFBTTtvQkFDTCxPQUFPLFFBQVEsS0FBSyxJQUFJLElBQUksSUFBSSxLQUFLLEVBQUUsR0FBRyxDQUFDLEdBQUcsSUFBSSxLQUFLLElBQUksS0FBSyxFQUFFLEdBQUcsRUFBRSxHQUFHLElBQUksR0FBRyxFQUFFLENBQUMsQ0FBQztpQkFDdEY7YUFDRjs7Ozs7O1FBRU8sK0NBQWlCOzs7OztZQUF6QixVQUEwQixJQUFZO2dCQUF0QyxpQkFrSUM7Z0JBaklDLElBQUksSUFBSSxDQUFDLE9BQU8sRUFBRTtvQkFDaEIsSUFBSSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7b0JBQ3JCLE9BQU87aUJBQ1I7cUJBQU07b0JBQ0wsSUFBSSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7aUJBQ3RCO2dCQUVELElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7O29CQUVoQixTQUFTLEdBQUcsSUFBSTtnQkFDcEIsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRTtvQkFDOUIsU0FBUyxHQUFHLE9BQUssSUFBTSxDQUFDO2lCQUN6QjtnQkFFRCxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFO29CQUM1QixTQUFTLEdBQU0sU0FBUyxPQUFJLENBQUM7aUJBQzlCO2dCQUVLLElBQUEsb0NBQThFLEVBQTdFLGVBQU8sRUFBRSxlQUFPLEVBQUUsYUFBSyxFQUFFLGtCQUFVLEVBQUUsYUFBSyxFQUFFLGlCQUFpQztnQkFFcEYsSUFBSSxTQUFTLENBQUMsS0FBSyxDQUFDLDZCQUE2QixDQUFDLEVBQUU7b0JBQ2xELElBQUksQ0FBQyxTQUFTLEdBQUcsU0FBUyxDQUFDO29CQUUzQixJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDMUQsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztpQkFDOUM7cUJBQU0sSUFBSSxTQUFTLENBQUMsS0FBSyxDQUFDLDhCQUE4QixDQUFDLEVBQUU7b0JBQzFELElBQUksQ0FBQyxTQUFTLEdBQUcsUUFBUSxDQUFDO29CQUUxQixJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDckQsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztvQkFDNUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztpQkFDN0M7cUJBQU0sSUFBSSxTQUFTLENBQUMsS0FBSyxDQUFDLDZCQUE2QixDQUFDLEVBQUU7b0JBQ3pELElBQUksQ0FBQyxTQUFTLEdBQUcsT0FBTyxDQUFDO29CQUV6QixJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsV0FBVyxDQUFDO29CQUN0QyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7O3dCQUM1RCxXQUFXLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQztvQkFDakMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxDQUFDO29CQUNqRSxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLENBQUM7b0JBQ3BFLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO29CQUNyRCxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztpQkFDdEQ7cUJBQU0sSUFBSSxTQUFTLENBQUMsS0FBSyxDQUFDLDhCQUE4QixDQUFDLEVBQUU7b0JBQzFELElBQUksQ0FBQyxTQUFTLEdBQUcsT0FBTyxDQUFDO29CQUV6QixJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsY0FBYyxDQUFDOzt3QkFDbkMsV0FBVyxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUM7b0JBQ2pDLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsQ0FBQztvQkFDcEUsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxDQUFDO29CQUN2RSxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztvQkFDeEQsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLE9BQU8sR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7aUJBQ3pEO3FCQUFNLElBQUksU0FBUyxDQUFDLEtBQUssQ0FBQyxxRkFBcUYsQ0FBQyxFQUFFO29CQUNqSCxJQUFJLENBQUMsU0FBUyxHQUFHLFFBQVEsQ0FBQztvQkFDMUIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFVBQUEsT0FBTyxJQUFJLE9BQUEsS0FBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEdBQUcsS0FBSyxHQUFBLENBQUMsQ0FBQztvQkFDL0UsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBQSxPQUFPLElBQUksT0FBQSxLQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsR0FBRyxJQUFJLEdBQUEsQ0FBQyxDQUFDOzt3QkFDckUsV0FBVyxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUM7b0JBQ2pDLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxDQUFDO29CQUN4RCxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsQ0FBQztvQkFDM0QsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztvQkFDNUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztpQkFDN0M7cUJBQU0sSUFBSSxTQUFTLENBQUMsS0FBSyxDQUFDLHdDQUF3QyxDQUFDLEVBQUU7b0JBQ3BFLElBQUksQ0FBQyxTQUFTLEdBQUcsU0FBUyxDQUFDO29CQUMzQixJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLEdBQUcsYUFBYSxDQUFDO29CQUUxQyxJQUFJLFVBQVUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUU7d0JBQ2xDLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxHQUFHLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDMUQsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQztxQkFDeEM7eUJBQU07d0JBQ0wsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLEdBQUcsR0FBRyxVQUFVLENBQUM7cUJBQ2pEO29CQUVELElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7d0JBQzdELFdBQVcsR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDO29CQUNqQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLENBQUM7b0JBQ3JFLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsQ0FBQztvQkFDeEUsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLE9BQU8sR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7b0JBQ3pELElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2lCQUMxRDtxQkFBTSxJQUFJLFNBQVMsQ0FBQyxLQUFLLENBQUMsc0VBQXNFLENBQUMsRUFBRTs7d0JBQzVGLEdBQUcsR0FBRyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7O3dCQUM1QixTQUFTLEdBQUcsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7b0JBQ3JDLElBQUksQ0FBQyxTQUFTLEdBQUcsU0FBUyxDQUFDO29CQUMzQixJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLEdBQUcsaUJBQWlCLENBQUM7b0JBQzlDLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxTQUFTLEdBQUcsU0FBUyxDQUFDO29CQUN6RCxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQztvQkFFN0MsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFO3dCQUN2QixJQUFBLDRDQUFtRCxFQUFsRCxrQkFBVSxFQUFFLGNBQXNDO3dCQUN6RCxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQzt3QkFDbkQsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLFVBQVUsR0FBRyxVQUFVLENBQUM7cUJBQzVEOzt3QkFFSyxXQUFXLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQztvQkFDakMsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxDQUFDO29CQUN6RSxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLENBQUM7b0JBQzVFLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO29CQUM3RCxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztpQkFDOUQ7cUJBQU0sSUFBSSxTQUFTLENBQUMsS0FBSyxDQUFDLHFDQUFxQyxDQUFDLEVBQUU7b0JBQ2pFLElBQUksQ0FBQyxTQUFTLEdBQUcsUUFBUSxDQUFDO29CQUMxQixJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsa0JBQWtCLENBQUM7b0JBQzlDLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLEtBQUssR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBRXpELElBQUksVUFBVSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRTt3QkFDbEMsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQzlELElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7cUJBQ3ZDO3lCQUFNO3dCQUNMLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsR0FBRyxVQUFVLENBQUM7cUJBQ3JEOzt3QkFFSyxXQUFXLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQztvQkFDakMsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLENBQUM7b0JBQ3pFLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxDQUFDO29CQUM1RSxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO29CQUM3RCxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2lCQUM5RDtxQkFBTSxJQUFJLFNBQVMsQ0FBQyxLQUFLLENBQUMsaUVBQWlFLENBQUMsRUFBRTs7d0JBQ3ZGLEdBQUcsR0FBRyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7O3dCQUM1QixTQUFTLEdBQUcsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7b0JBQ3JDLElBQUksQ0FBQyxTQUFTLEdBQUcsUUFBUSxDQUFDO29CQUMxQixJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsbUJBQW1CLENBQUM7b0JBQy9DLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUM7b0JBQzFELElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUM7b0JBQzlDLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEtBQUssR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7O3dCQUNwRCxXQUFXLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQztvQkFDakMsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLENBQUM7b0JBQzFFLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxDQUFDO29CQUM3RSxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO29CQUM5RCxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2lCQUMvRDtxQkFBTTtvQkFDTCxJQUFJLENBQUMsU0FBUyxHQUFHLFVBQVUsQ0FBQztvQkFDNUIsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztpQkFDdkM7YUFDRjs7Ozs7O1FBRU8sc0NBQVE7Ozs7O1lBQWhCLFVBQWlCLElBQVk7Z0JBQzNCLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7Z0JBQ3RDLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7Z0JBRXhDLElBQUksQ0FBQyxJQUFJLEVBQUU7b0JBQ1QsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsWUFBWSxHQUFHLGdDQUFnQyxDQUFDO29CQUN0RSxPQUFPO2lCQUNSOztvQkFFSyxTQUFTLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7O29CQUU3QixRQUFRLEdBQUcsQ0FBQztnQkFFaEIsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFO29CQUMvQixRQUFRLEVBQUUsQ0FBQztpQkFDWjtnQkFFRCxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUU7b0JBQzdCLFFBQVEsRUFBRSxDQUFDO2lCQUNaO2dCQUVELElBQUksU0FBUyxDQUFDLE1BQU0sS0FBSyxRQUFRLEVBQUU7b0JBQ2pDLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLFlBQVksR0FBRyw0Q0FBMEMsUUFBUSxjQUFXLENBQUM7b0JBQ25HLE9BQU87aUJBQ1I7Z0JBRUQsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztnQkFDckMsT0FBTzthQUNSOzs7OztRQUVPLDhEQUFnQzs7OztZQUF4QztnQkFDRSxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUU7b0JBQzNELE9BQU8sb0JBQW9CLENBQUM7aUJBQzdCO2dCQUVELElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRTtvQkFDM0QsT0FBTyxpQkFBaUIsQ0FBQztpQkFDMUI7Z0JBRUQsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRTtvQkFDMUQsT0FBTyxlQUFlLENBQUM7aUJBQ3hCO2dCQUVELE9BQU8sc0JBQXNCLENBQUM7YUFDL0I7Ozs7O1FBRU8sNkNBQWU7Ozs7WUFBdkI7Z0JBQ1EsSUFBQSwrREFBZ0csRUFBL0Ysb0JBQVksRUFBRSxzQkFBYyxFQUFFLHNCQUFpRTtnQkFFdEcsT0FBTztvQkFDTCxPQUFPLEVBQUU7d0JBQ1AsT0FBTyxFQUFFLENBQUM7d0JBQ1YsT0FBTyxFQUFFLENBQUM7cUJBQ1g7b0JBQ0QsTUFBTSxFQUFFO3dCQUNOLEtBQUssRUFBRSxDQUFDO3dCQUNSLE9BQU8sRUFBRSxDQUFDO3dCQUNWLE9BQU8sRUFBRSxDQUFDO3FCQUNYO29CQUNELEtBQUssRUFBRTt3QkFDTCxNQUFNLEVBQUUsV0FBVzt3QkFDbkIsU0FBUyxFQUFFOzRCQUNULElBQUksRUFBRSxDQUFDOzRCQUNQLEtBQUssRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLFlBQVksQ0FBQzs0QkFDckMsT0FBTyxFQUFFLGNBQWM7NEJBQ3ZCLE9BQU8sRUFBRSxjQUFjOzRCQUN2QixRQUFRLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUM7eUJBQ3pDO3dCQUNELFlBQVksRUFBRTs0QkFDWixLQUFLLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUM7NEJBQ3JDLE9BQU8sRUFBRSxjQUFjOzRCQUN2QixPQUFPLEVBQUUsY0FBYzs0QkFDdkIsUUFBUSxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDO3lCQUN6QztxQkFDRjtvQkFDRCxNQUFNLEVBQUU7d0JBQ04sR0FBRyxFQUFFLElBQUk7d0JBQ1QsR0FBRyxFQUFFLEtBQUs7d0JBQ1YsR0FBRyxFQUFFLEtBQUs7d0JBQ1YsR0FBRyxFQUFFLEtBQUs7d0JBQ1YsR0FBRyxFQUFFLEtBQUs7d0JBQ1YsR0FBRyxFQUFFLEtBQUs7d0JBQ1YsR0FBRyxFQUFFLEtBQUs7d0JBQ1YsS0FBSyxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDO3dCQUNyQyxPQUFPLEVBQUUsY0FBYzt3QkFDdkIsT0FBTyxFQUFFLGNBQWM7d0JBQ3ZCLFFBQVEsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLFlBQVksQ0FBQztxQkFDekM7b0JBQ0QsT0FBTyxFQUFFO3dCQUNQLE1BQU0sRUFBRSxhQUFhO3dCQUNyQixZQUFZLEVBQUUsS0FBSzt3QkFDbkIsV0FBVyxFQUFFOzRCQUNYLEdBQUcsRUFBRSxHQUFHOzRCQUNSLE1BQU0sRUFBRSxDQUFDOzRCQUNULEtBQUssRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLFlBQVksQ0FBQzs0QkFDckMsT0FBTyxFQUFFLGNBQWM7NEJBQ3ZCLE9BQU8sRUFBRSxjQUFjOzRCQUN2QixRQUFRLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUM7eUJBQ3pDO3dCQUNELGVBQWUsRUFBRTs0QkFDZixTQUFTLEVBQUUsSUFBSTs0QkFDZixHQUFHLEVBQUUsS0FBSzs0QkFDVixVQUFVLEVBQUUsQ0FBQzs0QkFDYixNQUFNLEVBQUUsQ0FBQzs0QkFDVCxLQUFLLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUM7NEJBQ3JDLE9BQU8sRUFBRSxjQUFjOzRCQUN2QixPQUFPLEVBQUUsY0FBYzs0QkFDdkIsUUFBUSxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDO3lCQUN6QztxQkFDRjtvQkFDRCxNQUFNLEVBQUU7d0JBQ04sTUFBTSxFQUFFLGtCQUFrQjt3QkFDMUIsWUFBWSxFQUFFLEtBQUs7d0JBQ25CLGdCQUFnQixFQUFFOzRCQUNoQixLQUFLLEVBQUUsQ0FBQzs0QkFDUixHQUFHLEVBQUUsR0FBRzs0QkFDUixLQUFLLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUM7NEJBQ3JDLE9BQU8sRUFBRSxjQUFjOzRCQUN2QixPQUFPLEVBQUUsY0FBYzs0QkFDdkIsUUFBUSxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDO3lCQUN6Qzt3QkFDRCxpQkFBaUIsRUFBRTs0QkFDakIsU0FBUyxFQUFFLElBQUk7NEJBQ2YsR0FBRyxFQUFFLEtBQUs7NEJBQ1YsS0FBSyxFQUFFLENBQUM7NEJBQ1IsS0FBSyxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDOzRCQUNyQyxPQUFPLEVBQUUsY0FBYzs0QkFDdkIsT0FBTyxFQUFFLGNBQWM7NEJBQ3ZCLFFBQVEsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLFlBQVksQ0FBQzt5QkFDekM7cUJBQ0Y7b0JBQ0QsUUFBUSxFQUFFO3dCQUNSLFVBQVUsRUFBRSxJQUFJLENBQUMsZ0NBQWdDLEVBQUU7cUJBQ3BEO29CQUNELFVBQVUsRUFBRTt3QkFDVixPQUFPLEVBQUUsSUFBSTt3QkFDYixZQUFZLEVBQUUsRUFBRTtxQkFDakI7aUJBQ0YsQ0FBQzthQUNIOzs7Ozs7UUFFTyw4Q0FBZ0I7Ozs7O1lBQXhCLFVBQXlCLEtBQWE7Z0JBQ3BDLElBQUksS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7O3dCQUNkLGlCQUFpQixHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7b0JBQ3hELElBQUksaUJBQWlCLEtBQUssR0FBRyxFQUFFO3dCQUM3QixPQUFPLElBQUksQ0FBQztxQkFDYjtpQkFDRjs7b0JBRUssU0FBUyxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7Z0JBQ2hELFFBQVEsU0FBUztvQkFDZixLQUFLLEdBQUc7d0JBQ04sT0FBTyxJQUFJLENBQUM7b0JBQ2QsS0FBSyxHQUFHO3dCQUNOLE9BQU8sSUFBSSxDQUFDO29CQUNkLEtBQUssR0FBRzt3QkFDTixPQUFPLElBQUksQ0FBQztvQkFDZDt3QkFDRSxPQUFPLElBQUksQ0FBQztpQkFDZjthQUNGOzs7OztRQUVPLDhDQUFnQjs7OztZQUF4QjtnQkFDRSxPQUFPO29CQUNMLE1BQU0sRUFBRSxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUM7b0JBQzdCLFVBQVUsRUFBRSxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDO29CQUMvQyxJQUFJLEVBQUUsQ0FBQyxLQUFLLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFLLENBQUM7b0JBQ3ZELE9BQU8sRUFBRSxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUM7b0JBQzlCLFdBQVcsRUFBRSxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUM7b0JBQ2xDLE9BQU8sRUFBRSxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUM7b0JBQzlCLEtBQUssRUFBRSxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUM7b0JBQzVCLFNBQVMsRUFBRSxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUM7b0JBQ2hDLGtCQUFrQixXQUFNLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRSxHQUFHLEVBQUM7b0JBQy9ELFNBQVMsRUFBRSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUM7aUJBQ3hCLENBQUM7YUFDSDs7b0JBemhCRkMsY0FBUyxTQUFDO3dCQUNULFFBQVEsRUFBRSxhQUFhO3dCQUN2QiwrOHNCQUEyQzs7cUJBRTVDOzs7K0JBRUVDLFVBQUs7OEJBQ0xBLFVBQUs7MkJBRUxBLFVBQUs7aUNBT0xDLFdBQU07O1FBMGdCVCwwQkFBQztLQTFoQkQ7Ozs7OztBQ05BO1FBSUE7WUFNbUIsV0FBTSxHQUFHLElBQUlILGlCQUFZLEVBQUUsQ0FBQztTQWtCOUM7Ozs7UUFOUSxzQ0FBUTs7O1lBQWY7Z0JBQ0UsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO2dCQUNoRixJQUFJLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO2dCQUNyQyxJQUFJLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO2dCQUNyQyxJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQy9COztvQkF2QkZDLGNBQVMsU0FBQzt3QkFDVCxRQUFRLEVBQUUsa0JBQWtCO3dCQUM1Qix1bUNBQTJDOztxQkFFNUM7Ozs2QkFFRUUsV0FBTTsrQkFDTkQsVUFBSzsyQkFDTEEsVUFBSztrQ0FDTEEsVUFBSztvQ0FDTEEsVUFBSztrQ0FDTEEsVUFBSzs7UUFhUiwwQkFBQztLQXhCRDs7Ozs7O0FDSkE7UUFPQTtTQUtpQzs7b0JBTGhDRSxhQUFRLFNBQUM7d0JBQ1IsWUFBWSxFQUFFLENBQUMsbUJBQW1CLEVBQUUsbUJBQW1CLENBQUM7d0JBQ3hELE9BQU8sRUFBRSxDQUFDQyxtQkFBWSxFQUFFQyxpQkFBVyxDQUFDO3dCQUNwQyxPQUFPLEVBQUUsQ0FBQyxtQkFBbUIsQ0FBQztxQkFDL0I7O1FBQytCLHVCQUFDO0tBTGpDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7In0=