import { BuilderContext, BuilderOutput } from "@angular-devkit/architect";
import { Observable } from 'rxjs';
import { Transforms } from "../utils";
export declare function buildWebpackBrowserPlus(options: any, context: BuilderContext, transforms?: Transforms): Observable<BuilderOutput>;
export { buildWebpackBrowserPlus as executeBrowserBuilderPlus };
declare const _default: import("@angular-devkit/architect/src/internal").Builder<any>;
export default _default;
