import { ExecutionTransformer } from "@angular-devkit/build-angular";
import { BuilderContext, BuilderOutputLike } from "@angular-devkit/architect";
import * as webpack from 'webpack';
export interface Transforms {
    webpackConfiguration?: ExecutionTransformer<webpack.Configuration>;
}
export interface BuilderHandlerPlusFn<A> {
    (input: A, context: BuilderContext, transforms: Transforms): BuilderOutputLike;
}
export declare function runBuilderHandler(options: any, transforms: Transforms, context: BuilderContext, builderHandler: BuilderHandlerPlusFn<any>, configTransformerName?: string): any;
