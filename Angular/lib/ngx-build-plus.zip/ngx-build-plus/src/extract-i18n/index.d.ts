import { BuilderContext, BuilderOutput } from "@angular-devkit/architect";
import { Observable } from 'rxjs';
import { Transforms } from "../utils";
import { JsonObject } from "@angular-devkit/core";
export declare function serveWebpackBrowserPlus(options: any, context: BuilderContext, transforms?: Transforms): Observable<BuilderOutput>;
declare const _default: import("@angular-devkit/architect/src/internal").Builder<JsonObject>;
export default _default;
