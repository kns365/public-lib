export declare function loadHook<T>(hook: string): T;
