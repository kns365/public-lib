export declare type ConfigHookFn = (cfg: object) => object;
export declare type Plugin = {
    config?(cfg: object, options?: object): object;
    pre?(builderConfig: any): void;
    post?(builderConfig: any): void;
};
