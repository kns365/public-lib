"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function loadHook(hook) {
    if (hook.startsWith('~')) {
        hook = process.cwd() + '/' + hook.substr(1);
    }
    return require(hook).default;
}
exports.loadHook = loadHook;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG9hZC1ob29rLmpzIiwic291cmNlUm9vdCI6Ii4vIiwic291cmNlcyI6WyJzcmMvZXh0L2xvYWQtaG9vay50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLFNBQWdCLFFBQVEsQ0FBSSxJQUFZO0lBQ3BDLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsRUFBRTtRQUN4QixJQUFJLEdBQUcsT0FBTyxDQUFDLEdBQUcsRUFBRSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO0tBQzdDO0lBQ0QsT0FBTyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBWSxDQUFDO0FBQ3RDLENBQUM7QUFMRCw0QkFLQyIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBmdW5jdGlvbiBsb2FkSG9vazxUPihob29rOiBzdHJpbmcpOiBUIHtcclxuICAgIGlmIChob29rLnN0YXJ0c1dpdGgoJ34nKSkge1xyXG4gICAgICBob29rID0gcHJvY2Vzcy5jd2QoKSArICcvJyArIGhvb2suc3Vic3RyKDEpO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHJlcXVpcmUoaG9vaykuZGVmYXVsdCBhcyBUO1xyXG59Il19