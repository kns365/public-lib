import { Tree } from "@angular-devkit/schematics";
export declare function getWorkspace(tree: Tree): any;
export declare function updateWorkspace(tree: Tree, workspace: any): void;
