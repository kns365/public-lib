export declare type AdvancedScriptConf = {
    bundleName: string;
    input: string;
};
