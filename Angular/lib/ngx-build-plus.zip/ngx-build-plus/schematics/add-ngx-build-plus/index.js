"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const workspace_1 = require("../utils/workspace");
function addNgxBuildPlus(_options) {
    return (tree, _context) => {
        const project = _options.project;
        const workspace = workspace_1.getWorkspace(tree);
        const architect = workspace.projects[project].architect;
        if (!architect)
            throw new Error(`expected node projects/${project}/architect in angular.json`);
        const build = architect.build;
        if (!build)
            throw new Error(`expected node projects/${project}/architect/build in angular.json`);
        // Custom Builders are not part of the CLI's enum
        build.builder = 'ngx-build-plus:browser';
        const serve = architect.serve;
        if (!serve)
            throw new Error(`expected node projects/${project}/architect/serve in angular.json`);
        serve.builder = 'ngx-build-plus:dev-server';
        const extractI18n = architect['extract-i18n'];
        if (extractI18n) {
            extractI18n.builder = 'ngx-build-plus:extract-i18n';
        }
        // We decided to not add our server builder by default, 
        // b/c the new jsdom-based Universal API only compiles
        // the server code (that is using the browser bundles) 
        // with this builder.
        //
        // const server = architect.server;
        // if (server) {
        //   server.builder = <any>'ngx-build-plus:server';
        // }
        const test = architect.test;
        if (test)
            test.builder = 'ngx-build-plus:karma';
        return workspace_1.updateWorkspace(tree, workspace);
    };
}
exports.addNgxBuildPlus = addNgxBuildPlus;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiLi8iLCJzb3VyY2VzIjpbInNjaGVtYXRpY3MvYWRkLW5neC1idWlsZC1wbHVzL2luZGV4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQ0Esa0RBQW1FO0FBRW5FLFNBQWdCLGVBQWUsQ0FBQyxRQUFhO0lBQzNDLE9BQU8sQ0FBQyxJQUFVLEVBQUUsUUFBMEIsRUFBRSxFQUFFO1FBRWhELE1BQU0sT0FBTyxHQUFHLFFBQVEsQ0FBQyxPQUFPLENBQUM7UUFDakMsTUFBTSxTQUFTLEdBQUcsd0JBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUVyQyxNQUFNLFNBQVMsR0FBRyxTQUFTLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQztRQUN4RCxJQUFJLENBQUMsU0FBUztZQUFFLE1BQU0sSUFBSSxLQUFLLENBQUMsMEJBQTBCLE9BQU8sNEJBQTRCLENBQUMsQ0FBQztRQUUvRixNQUFNLEtBQUssR0FBRyxTQUFTLENBQUMsS0FBSyxDQUFDO1FBQzlCLElBQUksQ0FBQyxLQUFLO1lBQUUsTUFBTSxJQUFJLEtBQUssQ0FBQywwQkFBMEIsT0FBTyxrQ0FBa0MsQ0FBQyxDQUFDO1FBRWpHLGlEQUFpRDtRQUNqRCxLQUFLLENBQUMsT0FBTyxHQUFRLHdCQUF3QixDQUFDO1FBRTlDLE1BQU0sS0FBSyxHQUFHLFNBQVMsQ0FBQyxLQUFLLENBQUM7UUFDOUIsSUFBSSxDQUFDLEtBQUs7WUFBRSxNQUFNLElBQUksS0FBSyxDQUFDLDBCQUEwQixPQUFPLGtDQUFrQyxDQUFDLENBQUM7UUFFakcsS0FBSyxDQUFDLE9BQU8sR0FBUSwyQkFBMkIsQ0FBQztRQUVqRCxNQUFNLFdBQVcsR0FBRyxTQUFTLENBQUMsY0FBYyxDQUFDLENBQUM7UUFDOUMsSUFBSSxXQUFXLEVBQUU7WUFDZixXQUFXLENBQUMsT0FBTyxHQUFRLDZCQUE2QixDQUFDO1NBQzFEO1FBRUQsd0RBQXdEO1FBQ3hELHNEQUFzRDtRQUN0RCx1REFBdUQ7UUFDdkQscUJBQXFCO1FBQ3JCLEVBQUU7UUFDRixtQ0FBbUM7UUFDbkMsZ0JBQWdCO1FBQ2hCLG1EQUFtRDtRQUNuRCxJQUFJO1FBRUosTUFBTSxJQUFJLEdBQUcsU0FBUyxDQUFDLElBQUksQ0FBQztRQUM1QixJQUFJLElBQUk7WUFBRSxJQUFJLENBQUMsT0FBTyxHQUFRLHNCQUFzQixDQUFDO1FBRXJELE9BQU8sMkJBQWUsQ0FBQyxJQUFJLEVBQUUsU0FBUyxDQUFDLENBQUM7SUFDMUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQztBQXhDRCwwQ0F3Q0MiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBSdWxlLCBTY2hlbWF0aWNDb250ZXh0LCBUcmVlIH0gZnJvbSAnQGFuZ3VsYXItZGV2a2l0L3NjaGVtYXRpY3MnO1xyXG5pbXBvcnQgeyBnZXRXb3Jrc3BhY2UsIHVwZGF0ZVdvcmtzcGFjZSB9IGZyb20gJy4uL3V0aWxzL3dvcmtzcGFjZSc7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gYWRkTmd4QnVpbGRQbHVzKF9vcHRpb25zOiBhbnkpOiBSdWxlIHtcclxuICByZXR1cm4gKHRyZWU6IFRyZWUsIF9jb250ZXh0OiBTY2hlbWF0aWNDb250ZXh0KSA9PiB7XHJcbiAgICBcclxuICAgIGNvbnN0IHByb2plY3QgPSBfb3B0aW9ucy5wcm9qZWN0O1xyXG4gICAgY29uc3Qgd29ya3NwYWNlID0gZ2V0V29ya3NwYWNlKHRyZWUpO1xyXG5cclxuICAgIGNvbnN0IGFyY2hpdGVjdCA9IHdvcmtzcGFjZS5wcm9qZWN0c1twcm9qZWN0XS5hcmNoaXRlY3Q7XHJcbiAgICBpZiAoIWFyY2hpdGVjdCkgdGhyb3cgbmV3IEVycm9yKGBleHBlY3RlZCBub2RlIHByb2plY3RzLyR7cHJvamVjdH0vYXJjaGl0ZWN0IGluIGFuZ3VsYXIuanNvbmApO1xyXG5cclxuICAgIGNvbnN0IGJ1aWxkID0gYXJjaGl0ZWN0LmJ1aWxkO1xyXG4gICAgaWYgKCFidWlsZCkgdGhyb3cgbmV3IEVycm9yKGBleHBlY3RlZCBub2RlIHByb2plY3RzLyR7cHJvamVjdH0vYXJjaGl0ZWN0L2J1aWxkIGluIGFuZ3VsYXIuanNvbmApO1xyXG5cclxuICAgIC8vIEN1c3RvbSBCdWlsZGVycyBhcmUgbm90IHBhcnQgb2YgdGhlIENMSSdzIGVudW1cclxuICAgIGJ1aWxkLmJ1aWxkZXIgPSA8YW55PiduZ3gtYnVpbGQtcGx1czpicm93c2VyJztcclxuXHJcbiAgICBjb25zdCBzZXJ2ZSA9IGFyY2hpdGVjdC5zZXJ2ZTtcclxuICAgIGlmICghc2VydmUpIHRocm93IG5ldyBFcnJvcihgZXhwZWN0ZWQgbm9kZSBwcm9qZWN0cy8ke3Byb2plY3R9L2FyY2hpdGVjdC9zZXJ2ZSBpbiBhbmd1bGFyLmpzb25gKTtcclxuXHJcbiAgICBzZXJ2ZS5idWlsZGVyID0gPGFueT4nbmd4LWJ1aWxkLXBsdXM6ZGV2LXNlcnZlcic7XHJcblxyXG4gICAgY29uc3QgZXh0cmFjdEkxOG4gPSBhcmNoaXRlY3RbJ2V4dHJhY3QtaTE4biddO1xyXG4gICAgaWYgKGV4dHJhY3RJMThuKSB7XHJcbiAgICAgIGV4dHJhY3RJMThuLmJ1aWxkZXIgPSA8YW55PiduZ3gtYnVpbGQtcGx1czpleHRyYWN0LWkxOG4nO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIFdlIGRlY2lkZWQgdG8gbm90IGFkZCBvdXIgc2VydmVyIGJ1aWxkZXIgYnkgZGVmYXVsdCwgXHJcbiAgICAvLyBiL2MgdGhlIG5ldyBqc2RvbS1iYXNlZCBVbml2ZXJzYWwgQVBJIG9ubHkgY29tcGlsZXNcclxuICAgIC8vIHRoZSBzZXJ2ZXIgY29kZSAodGhhdCBpcyB1c2luZyB0aGUgYnJvd3NlciBidW5kbGVzKSBcclxuICAgIC8vIHdpdGggdGhpcyBidWlsZGVyLlxyXG4gICAgLy9cclxuICAgIC8vIGNvbnN0IHNlcnZlciA9IGFyY2hpdGVjdC5zZXJ2ZXI7XHJcbiAgICAvLyBpZiAoc2VydmVyKSB7XHJcbiAgICAvLyAgIHNlcnZlci5idWlsZGVyID0gPGFueT4nbmd4LWJ1aWxkLXBsdXM6c2VydmVyJztcclxuICAgIC8vIH1cclxuXHJcbiAgICBjb25zdCB0ZXN0ID0gYXJjaGl0ZWN0LnRlc3Q7XHJcbiAgICBpZiAodGVzdCkgdGVzdC5idWlsZGVyID0gPGFueT4nbmd4LWJ1aWxkLXBsdXM6a2FybWEnO1xyXG5cclxuICAgIHJldHVybiB1cGRhdGVXb3Jrc3BhY2UodHJlZSwgd29ya3NwYWNlKTtcclxuICB9O1xyXG59XHJcblxyXG4gIFxyXG4iXX0=