import { Rule } from '@angular-devkit/schematics';
export declare function addNgxBuildPlus(_options: any): Rule;
