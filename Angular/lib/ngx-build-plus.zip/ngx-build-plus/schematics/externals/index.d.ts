import { Rule } from '@angular-devkit/schematics';
export declare function addExternalsSupport(_options: any): Rule;
