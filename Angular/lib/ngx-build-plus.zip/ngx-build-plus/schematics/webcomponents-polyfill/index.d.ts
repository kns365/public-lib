import { Rule } from '@angular-devkit/schematics';
export declare function npmRun(options: any): Rule;
export declare function addWebComponentsPolyfill(_options: any): Rule;
